
import { GoogleGenAI, Type } from "@google/genai";
import type { EmailAccount, CandidateMatch } from "../types";

// FIX: Per @google/genai coding guidelines, the API key must be obtained exclusively from process.env.API_KEY.
// const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

// Lazily initialize the AI instance to avoid errors on app startup if key is missing.
// The main app logic in App.tsx should prevent this from being called without a key anyway.
let ai: GoogleGenAI | null = null;
const getAiInstance = () => {
    if (!ai) {
        // FIX: Per @google/genai coding guidelines, the API key must be obtained from process.env.API_KEY.
        const apiKey = process.env.API_KEY;
        if (apiKey) {
            ai = new GoogleGenAI({ apiKey });
        }
    }
    return ai;
}

export const suggestUsernames = async (fullName: string): Promise<string[]> => {
  const aiInstance = getAiInstance();
  // Fallback if the AI instance couldn't be created (e.g., missing API key)
  if (!aiInstance) {
    console.warn("Gemini AI not initialized. Using fallback suggestions.");
    const basicUsername = fullName.toLowerCase().replace(/\s+/g, '.');
    return [`${basicUsername}`, `${basicUsername}1`, `${basicUsername}2`];
  }
  
  try {
    const prompt = `بناءً على الاسم الكامل "${fullName}"، اقترح 3 أسماء مستخدمين فريدة واحترافية للبريد الإلكتروني. يجب أن تكون الأسماء قصيرة وسهلة التذكر. لا تقم بتضمين أي رموز خاصة باستثناء النقطة (.) أو الشرطة السفلية (_).`;

    const response = await aiInstance.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.STRING
            },
            description: "A list of suggested usernames"
          }
        }
    });
    
    const text = response.text.trim();
    const suggestions = JSON.parse(text);
    return suggestions.slice(0, 3);
  } catch (error) {
    console.error("Error suggesting usernames:", error);
    // Fallback in case of API error
    const basicUsername = fullName.toLowerCase().replace(/\s+/g, '.');
    return [`${basicUsername}`, `${basicUsername}1`, `${basicUsername}2`];
  }
};

export const generatePasswordRecoveryEmail = async (fullName: string, username: string, email: string, password?: string): Promise<{ subject: string; body: string; }> => {
  const fallbackEmail = {
    subject: `استعادة بيانات حسابك في اتحاد بشبابها`,
    body: `مرحباً ${fullName},\n\nبناءً على طلبك، إليك بيانات حسابك:\n\nالبريد الإلكتروني: ${email}\nكلمة المرور: ${password}\n\nنرجو الحفاظ على سرية هذه البيانات.\n\nمع تحياتنا،\nإدارة اتحاد بشبابها`
  };

  const aiInstance = getAiInstance();
  if (!aiInstance) {
    console.warn("Gemini AI not initialized. Using fallback email.");
    return fallbackEmail;
  }

  try {
    const prompt = `
      اكتب رسالة بريد إلكتروني احترافية باللغة العربية لاستعادة بيانات حساب.
      المرسل هو "إدارة اتحاد بشبابها".
      المرسل إليه هو "${fullName}".
      
      يجب أن تحتوي الرسالة على البيانات التالية:
      - البريد الإلكتروني الرسمي: ${email}
      - كلمة المرور: ${password}
      
      الرسالة يجب أن تكون ودودة ورسمية في نفس الوقت. ابدأ بالتحية، ثم اذكر أنه تم استلام طلب لاستعادة البيانات، ثم قدم البيانات المطلوبة، واختتم بنصيحة للحفاظ على سرية البيانات وشكر.
      
      الموضوع يجب أن يكون "استعادة بيانات حسابك في اتحاد بشبابها" أو شيئًا مشابهًا.
    `;

    const response = await aiInstance.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              subject: { type: Type.STRING, description: "موضوع البريد الإلكتروني" },
              body: { type: Type.STRING, description: "محتوى البريد الإلكتروني بالكامل" },
            },
            required: ['subject', 'body'],
          }
        }
    });

    const text = response.text.trim();
    const emailContent = JSON.parse(text);
    return emailContent;

  } catch (error) {
    console.error("Error generating password recovery email:", error);
    return fallbackEmail;
  }
};


export const findBestCandidates = async (opportunityDescription: string, accounts: EmailAccount[]): Promise<CandidateMatch[]> => {
    const aiInstance = getAiInstance();
    if (!aiInstance) {
        console.warn("Gemini AI not initialized. Cannot perform candidate search.");
        throw new Error("AI service is not available.");
    }

    // Sanitize and simplify account data to send only relevant information
    const memberProfiles = accounts.map(acc => ({
        id: acc.id,
        fullName: acc.fullName,
        governorate: acc.governorate,
        unionPosition: acc.unionPosition,
        qualification: acc.qualification,
        specialization: acc.specialization,
        studyStatus: acc.studyStatus,
        currentJob: acc.currentJob,
        jobType: acc.jobType,
        yearsOfExperience: acc.yearsOfExperience,
        expertiseAreas: acc.expertiseAreas,
        professionalSkills: acc.professionalSkills,
        availableForVolunteering: acc.availableForVolunteering,
        preferredVolunteeringAreas: acc.preferredVolunteeringAreas,
        personalSkills: acc.personalSkills,
        interestedInAreas: acc.interestedInAreas,
        strengths: acc.strengths,
        developmentAreas: acc.developmentAreas,
        committee: acc.committee
    }));

    const prompt = `
      أنت خبير توظيف وموارد بشرية في اتحاد شبابي. مهمتك هي تحليل قائمة من ملفات الأعضاء واقتراح أفضل المرشحين بناءً على وصف فرصة معينة.

      وصف الفرصة:
      "${opportunityDescription}"

      ملفات الأعضاء:
      ${JSON.stringify(memberProfiles)}

      المطلوب:
      قم بمراجعة كل ملف شخصي وقارنه بمتطلبات الفرصة. أرجع قائمة بالمرشحين الأكثر صلة، مرتبة من الأعلى إلى الأقل ملاءمة.
      - يجب أن تكون "matchPercentage" نسبة مئوية تقديرية لمدى ملاءمة المرشح.
      - يجب أن يكون "reasoning" شرحًا موجزًا ومباشرًا على شكل نقاط، يوضح سبب ترشيح هذا العضو.
      - قم بإرجاع 5 مرشحين كحد أقصى.
    `;

    try {
        const response = await aiInstance.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            accountId: { type: Type.STRING, description: "معرّف العضو (id)" },
                            matchPercentage: { type: Type.NUMBER, description: "نسبة المطابقة من 0 إلى 100" },
                            reasoning: { type: Type.STRING, description: "سبب الترشيح في نقاط" },
                        },
                        required: ['accountId', 'matchPercentage', 'reasoning'],
                    },
                },
            },
        });

        const text = response.text.trim();
        const candidates: CandidateMatch[] = JSON.parse(text);
        return candidates.sort((a, b) => b.matchPercentage - a.matchPercentage);
    } catch (error) {
        console.error("Error finding best candidates:", error);
        throw new Error("Failed to get candidate suggestions from AI service.");
    }
};
