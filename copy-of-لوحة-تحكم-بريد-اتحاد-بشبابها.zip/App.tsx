import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendPasswordResetEmail, type User } from 'firebase/auth';
import { collection, onSnapshot, doc, setDoc, updateDoc, deleteDoc, addDoc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL, deleteObject } from 'firebase/storage';

import { auth, db, storage, isFirebaseConfigured } from './services/firebase';
import type { EmailAccount, Alert, Message, Event } from './types';

import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import MailboxPage from './components/MailboxPage';
import AdminPage from './components/AdminPage';
import AdminLoginPage from './components/AdminLoginPage';
import LoadingSpinner from './components/LoadingSpinner';
import ConfigErrorPage from './components/ConfigErrorPage';

const App: React.FC = () => {
  const [view, setView] = useState<'loading' | 'login' | 'register' | 'mailbox' | 'admin-login' | 'admin'>('loading');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<EmailAccount | null>(null);
  
  const [accounts, setAccounts] = useState<EmailAccount[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [events, setEvents] = useState<Event[]>([]);

  const [loginMessage, setLoginMessage] = useState<string | null>(null);
  const [theme, setTheme] = useState<string>(() => localStorage.getItem('theme') || 'system');
  
  useEffect(() => {
    if (!isFirebaseConfigured || !auth || !db) {
        setView('loading'); // Keep loading until check is done
        console.error("Firebase is not configured. Please check your environment variables.");
        return;
    }

    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
        setCurrentUser(user);
        if (!user) {
            setView(view === 'admin-login' ? 'admin-login' : 'login');
            setCurrentUserProfile(null);
        }
    });

    return () => unsubscribeAuth();
  }, [view]);
  
  useEffect(() => {
    if (!isFirebaseConfigured || !db) return;
    
    const setupListeners = () => {
        const collections: { name: string, setter: React.Dispatch<React.SetStateAction<any[]>> }[] = [
            { name: 'accounts', setter: setAccounts },
            { name: 'alerts', setter: setAlerts },
            { name: 'messages', setter: setMessages },
            { name: 'events', setter: setEvents },
        ];

        const unsubscribers = collections.map(({ name, setter }) => {
            const q = query(collection(db, name), orderBy('createdAt', 'desc'));
            return onSnapshot(q, (snapshot) => {
                const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any[];
                setter(data);
            });
        });

        return () => unsubscribers.forEach(unsub => unsub());
    };

    const unsub = setupListeners();
    return unsub;
  }, []);

  useEffect(() => {
    if (currentUser && db) {
        const unsub = onSnapshot(doc(db, 'accounts', currentUser.uid), (doc) => {
            if (doc.exists()) {
                const userProfile = { id: doc.id, ...doc.data() } as EmailAccount;
                setCurrentUserProfile(userProfile);
                if (userProfile.email === 'admin@youthunion.org') {
                  setView('admin');
                } else {
                  setView('mailbox');
                }
            } else {
                // This might happen if the firestore doc is deleted but auth user isn't.
                handleLogout();
            }
        });
        return () => unsub();
    }
  }, [currentUser]);

  useEffect(() => {
    const root = window.document.documentElement;
    const isDark =
      theme === 'dark' ||
      (theme === 'system' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    root.classList.toggle('dark', isDark);
    localStorage.setItem('theme', theme);

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
      if (theme === 'system') {
        root.classList.toggle('dark', mediaQuery.matches);
      }
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme]);

  const handleLogin = async (email: string, password: string): Promise<void> => {
    if (!auth) throw new Error("Auth not initialized");
    await signInWithEmailAndPassword(auth, email, password);
    setLoginMessage(null);
  };

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
    setCurrentUser(null);
    setCurrentUserProfile(null);
    setView('login');
  };

  const handleAccountCreate = async (accountData: EmailAccount) => {
    if (!auth || !db || !storage) throw new Error("Firebase not initialized");

    const userCredential = await createUserWithEmailAndPassword(auth, accountData.email, accountData.password!);
    const user = userCredential.user;

    let profilePictureUrl = '';
    if (accountData.profilePicture) {
        const storageRef = ref(storage, `profilePictures/${user.uid}`);
        const snapshot = await uploadString(storageRef, accountData.profilePicture, 'data_url');
        profilePictureUrl = await getDownloadURL(snapshot.ref);
    }
    
    const { password, ...firestoreData } = accountData; // Don't store password in Firestore
    
    await setDoc(doc(db, "accounts", user.uid), {
        ...firestoreData,
        id: user.uid,
        profilePicture: profilePictureUrl,
        createdAt: serverTimestamp()
    });
    
    setLoginMessage(`تهانينا ${accountData.fullName}! تم إنشاء حسابك بنجاح. يمكنك الآن تسجيل الدخول.`);
    setView('login');
  };

  const handleBulkCreate = async (newAccounts: EmailAccount[]) => {
      if (!db) return;
      const promises = newAccounts.map(account => {
          const { password, ...firestoreData } = account;
          return addDoc(collection(db, 'accounts'), { ...firestoreData, createdAt: serverTimestamp() });
      });
      await Promise.all(promises);
      alert(`تم إضافة ${newAccounts.length} حسابات جديدة إلى قاعدة البيانات. ملاحظة: يجب إنشاء حسابات الدخول لهم يدويًا في لوحة تحكم Firebase Authentication.`);
  };

  const handleAccountDelete = async (idToDelete: string) => {
    if (!db || !storage) return;
    const accountToDelete = accounts.find(a => a.id === idToDelete);
    if (!accountToDelete) return;

    if (accountToDelete.profilePicture) {
        try {
            const pictureRef = ref(storage, `profilePictures/${idToDelete}`);
            await deleteObject(pictureRef);
        } catch (error: any) {
             if (error.code !== 'storage/object-not-found') {
                console.error("Error deleting profile picture:", error);
            }
        }
    }
    await deleteDoc(doc(db, "accounts", idToDelete));
  };
  
  const handleAccountUpdate = async (updatedAccount: EmailAccount) => {
    if (!db) return;
    const { id, ...dataToUpdate } = updatedAccount;
    const docRef = doc(db, 'accounts', id);
    await updateDoc(docRef, dataToUpdate);
  };

  const handleSendAlert = async (alertData: { subject: string; body: string; }) => {
    if (!db) return;
    await addDoc(collection(db, 'alerts'), { ...alertData, createdAt: serverTimestamp() });
    alert('تم إرسال التنبيه العاجل بنجاح لجميع الأعضاء.');
  };

  const handleSendMessage = async (messageData: { from: string; to: string[]; subject: string; body: string; }) => {
    if (!db) return;
    await addDoc(collection(db, 'messages'), { ...messageData, read: false, createdAt: serverTimestamp() });
    alert('تم إرسال الرسالة بنجاح.');
  };
  
  const handleCreateEvent = async (eventData: { name: string; date: string; location: string; description: string; }) => {
    if (!db) return;
    const newEventRef = await addDoc(collection(db, 'events'), {
        ...eventData,
        createdBy: 'admin',
        createdAt: serverTimestamp(),
        attendees: [],
        declined: [],
    });

    const allMemberEmails = accounts.filter(acc => acc.username !== 'admin').map(acc => acc.email);
    if (allMemberEmails.length > 0) {
        await addDoc(collection(db, 'messages'), {
            from: 'admin@youthunion.org',
            to: allMemberEmails,
            subject: `دعوة للمشاركة في: ${eventData.name}`,
            body: eventData.description,
            createdAt: serverTimestamp(),
            read: false,
            type: 'event',
            eventId: newEventRef.id,
        });
    }
    alert('تم إنشاء الفاعلية وإرسال الدعوات بنجاح.');
  };

  const handleRegisterForEvent = async (eventId: string, userId: string) => {
    if (!db) return;
    const event = events.find(e => e.id === eventId);
    if (!event) return;

    const attendees = event.attendees.includes(userId) ? event.attendees : [...event.attendees, userId];
    const declined = event.declined?.filter(id => id !== userId) ?? [];
    await updateDoc(doc(db, 'events', eventId), { attendees, declined });
  };
  
  const handleDeclineEvent = async (eventId: string, userId: string) => {
    if (!db) return;
    const event = events.find(e => e.id === eventId);
    if (!event) return;
    
    const attendees = event.attendees.filter(id => id !== userId);
    const declined = event.declined?.includes(userId) ? event.declined : [...(event.declined ?? []), userId];
    await updateDoc(doc(db, 'events', eventId), { attendees, declined });
  };
  
  const handlePasswordReset = async (email: string) => {
    if (!auth) return;
    await sendPasswordResetEmail(auth, email);
  };
  
  if (!isFirebaseConfigured) {
    return <ConfigErrorPage />;
  }
  
  if (view === 'loading' || (currentUser && !currentUserProfile)) {
    return <LoadingSpinner />;
  }
  
  if (view === 'admin' && currentUserProfile?.email === 'admin@youthunion.org') {
    return <AdminPage 
      onLogout={handleLogout}
      allAccounts={accounts.filter(a => a.email !== 'admin@youthunion.org')}
      events={events}
      onUpdateAccount={handleAccountUpdate}
      onDeleteAccount={handleAccountDelete}
      onSendAlert={handleSendAlert}
      onSendMessage={handleSendMessage}
      onAccountCreate={handleAccountCreate}
      onBulkCreate={handleBulkCreate}
      onCreateEvent={handleCreateEvent}
      syncStatus={'idle'}
    />
  }

  if (view === 'mailbox' && currentUserProfile) {
    return <MailboxPage 
      currentUserAccount={currentUserProfile}
      onLogout={handleLogout}
      allAccounts={accounts}
      alerts={alerts}
      messages={messages}
      events={events}
      onSendMessage={handleSendMessage}
      onUpdateAccount={handleAccountUpdate}
      onRegisterForEvent={handleRegisterForEvent}
      onDeclineEvent={handleDeclineEvent}
      theme={theme}
      onSetTheme={setTheme}
      syncStatus={'idle'}
    />;
  }

  if (view === 'register') {
    return <RegisterPage 
      onNavigateToLogin={() => setView('login')} 
      onAccountCreate={handleAccountCreate}
      accounts={accounts}
    />;
  }
  
  if (view === 'admin-login') {
    return <AdminLoginPage
      onLogin={handleLogin}
      onNavigateToLogin={() => setView('login')}
    />;
  }
  
  return <LoginPage 
    loginMessage={loginMessage}
    onNavigateToRegister={() => { setLoginMessage(null); setView('register'); }}
    onNavigateToAdminLogin={() => { setLoginMessage(null); setView('admin-login'); }}
    onLogin={handleLogin}
    onPasswordReset={handlePasswordReset}
  />;
};

type View = 'loading' | 'login' | 'register' | 'mailbox' | 'admin-login' | 'admin';

export default App;
