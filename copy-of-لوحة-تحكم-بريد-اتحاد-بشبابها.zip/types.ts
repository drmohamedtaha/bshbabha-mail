export interface Participation {
  id: string;
  eventName: string;
  date: string;
  role: string;
  description: string;
}

export interface Event {
  id: string;
  name: string;
  date: string;
  location: string;
  description: string;
  createdBy: string; // 'admin'
  createdAt: string;
  attendees: string[]; // Array of EmailAccount IDs
  declined?: string[]; // Array of EmailAccount IDs
}

export interface EmailAccount {
  id: string;
  fullName: string;
  username: string;
  email: string;
  password?: string;
  createdAt: string;
  // New detailed fields
  nationalId: string;
  dateOfBirth: string;
  governorate: string;
  unionPosition: string;
  mobileNumber: string;
  whatsappNumber: string;
  personalEmail: string;
  profilePicture?: string;
  signature?: string;
  participations: Participation[];

  // --- New Fields based on user request ---

  // Personal Information
  gender?: 'ذكر' | 'أنثى';
  maritalStatus?: string;
  address?: string; // العنوان بالتفصيل
  additionalMobileNumber?: string;
  socialMediaLink?: string; // رابط فيسبوك / انستجرام

  // Educational Status
  qualification?: string; // المؤهل الدراسي
  specialization?: string; // التخصص
  graduationYear?: number; // سنة التخرج
  studyStatus?: 'طالب' | 'خريج' | 'دراسات عليا'; // الحالة الدراسية
  university?: string; // الجامعة/المدرسة
  gpa?: string; // معدل/تقدير التخرج
  trainingCourses?: string; // دورات تدريبية, using string for textarea
  educationSkills?: string; // المهارات المرتبطة بالتعليم, using string for textarea

  // Professional Status
  currentJob?: string; // الوظيفة الحالية
  employer?: string; // جهة العمل
  jobType?: 'حكومي' | 'خاص' | 'حر' | 'غير عامل'; // طبيعة العمل
  yearsOfExperience?: number; // سنوات الخبرة
  expertiseAreas?: string; // مجالات الخبرة, using string for textarea
  previousProjects?: string; // المشاريع السابقة, using string for textarea
  professionalSkills?: string; // المهارات المهنية, using string for textarea
  availableForVolunteering?: boolean; // إمكانية العمل التطوعي
  preferredVolunteeringAreas?: string; // المجالات التطوعية, using string for textarea

  // Interests and Abilities
  personalSkills?: string; // المهارات الشخصية, using string for textarea
  hobbies?: string; // الهوايات والأنشطة, using string for textarea
  interestedInAreas?: string; // المجالات التي يرغب في المشاركة فيها, using string for textarea
  strengths?: string; // أهم نقاط القوة, using string for textarea
  developmentAreas?: string; // نقاط يرغب في تطويرها, using string for textarea

  // Union Membership Data (Admin-managed)
  committee?: string; // اللجنة أو الفريق التابع له
  unionAchievements?: string; // الإنجازات السابقة, using string for textarea
  commitmentRating?: 1 | 2 | 3 | 4 | 5; // تقييم التزام العضو
  availability?: 'يوميًا' | 'أسبوعيًا' | 'شهريًا'; // مدى توافُره
}


export interface Alert {
  id: string;
  subject: string;
  body: string;
  createdAt: string;
}

export interface Message {
  id: string;
  from: string;
  to: string[];
  subject: string;
  body: string;
  createdAt: string;
  read: boolean;
  type?: 'standard' | 'event';
  eventId?: string;
}

export interface CandidateMatch {
  accountId: string;
  matchPercentage: number;
  reasoning: string;
}
