import React, { useState } from 'react';
import type { EmailAccount, Participation } from '../types';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';
import ClipboardDocumentListIcon from './icons/ClipboardDocumentListIcon';
import TrophyIcon from './icons/TrophyIcon';
import CalendarDaysIcon from './icons/CalendarDaysIcon';
import Avatar from './Avatar';

interface ParticipationLogViewProps {
  account: EmailAccount;
  onUpdateAccount: (account: EmailAccount) => void;
}

const ParticipationLogView: React.FC<ParticipationLogViewProps> = ({ account, onUpdateAccount }) => {
  const [eventName, setEventName] = useState('');
  const [date, setDate] = useState('');
  const [role, setRole] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');

  const resetForm = () => {
    setEventName('');
    setDate('');
    setRole('');
    setDescription('');
    setError('');
  };

  const handleAddParticipation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventName || !date || !role || !description) {
      setError('الرجاء ملء جميع الحقول.');
      return;
    }

    const newParticipation: Participation = {
      id: crypto.randomUUID(),
      eventName,
      date,
      role,
      description,
    };

    const updatedParticipations = [...(account.participations || []), newParticipation];
    onUpdateAccount({ ...account, participations: updatedParticipations });
    resetForm();
  };
  
  const handleDeleteParticipation = (idToDelete: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذه المشاركة؟')) {
        const updatedParticipations = (account.participations || []).filter(p => p.id !== idToDelete);
        onUpdateAccount({ ...account, participations: updatedParticipations });
    }
  };

  const participations = account.participations || [];

  return (
    <div className="p-4 sm:p-6 lg:p-8 h-full flex flex-col">
        <header className="pb-6 border-b border-slate-200 dark:border-slate-700 mb-6 flex items-start justify-between flex-wrap gap-4">
            <div>
                <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-3">
                    <ClipboardDocumentListIcon className="w-8 h-8 text-amber-500" />
                    سجل المشاركات والأنشطة
                </h1>
                <p className="text-slate-500 dark:text-slate-400 mt-2">
                    هنا يمكنك تسجيل وتتبع جميع الفعاليات والأنشطة التي تشارك فيها.
                </p>
            </div>
            <div className="flex items-center gap-3 text-right flex-shrink-0 ml-auto bg-slate-50 dark:bg-slate-800 p-2 rounded-full border border-slate-200 dark:border-slate-700">
                <div className="flex flex-col items-end pr-2">
                    <span className="font-semibold text-slate-700 dark:text-slate-200">{account.fullName}</span>
                    <span className="text-sm text-slate-500 dark:text-slate-400">{account.unionPosition}</span>
                </div>
                <Avatar account={account} size="w-12 h-12" />
            </div>
        </header>

        <div className="flex-1 overflow-y-auto pr-2">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                    <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 sticky top-6">
                        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">إضافة مشاركة جديدة</h2>
                        <form onSubmit={handleAddParticipation} className="space-y-4">
                        <div>
                            <label htmlFor="eventName" className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">اسم الفعالية/النشاط</label>
                            <input type="text" id="eventName" value={eventName} onChange={(e) => setEventName(e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-slate-700 dark:border-slate-600 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
                        </div>
                        <div>
                            <label htmlFor="date" className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">تاريخ المشاركة</label>
                            <input type="date" id="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-slate-700 dark:border-slate-600 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
                        </div>
                        <div>
                            <label htmlFor="role" className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">دورك (مثال: منظم، مشارك، متحدث)</label>
                            <input type="text" id="role" value={role} onChange={(e) => setRole(e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-slate-700 dark:border-slate-600 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
                        </div>
                        <div>
                            <label htmlFor="description" className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">وصف موجز</label>
                            <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} className="w-full px-3 py-2 bg-white dark:bg-slate-700 dark:border-slate-600 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required></textarea>
                        </div>
                        {error && <p className="text-sm text-red-600">{error}</p>}
                        <button type="submit" className="w-full flex items-center justify-center gap-2 bg-amber-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-amber-600 transition-colors shadow-sm">
                            <PlusIcon className="w-5 h-5" />
                            <span>إضافة</span>
                        </button>
                        </form>
                    </div>
                </div>
                <div className="lg:col-span-2">
                    {participations.length === 0 ? (
                        <div className="text-center py-20 px-6 bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700">
                            <ClipboardDocumentListIcon className="w-16 h-16 mx-auto text-slate-300 dark:text-slate-600" />
                            <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-300 mt-4">لم تقم بتسجيل أي مشاركات بعد</h3>
                            <p className="text-slate-500 dark:text-slate-400 mt-2">استخدم النموذج على اليمين لإضافة أول مشاركة لك.</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                        {participations.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(p => (
                            <div key={p.id} className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm transition-shadow hover:shadow-md relative group">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                                            <ClipboardDocumentListIcon className="w-5 h-5 text-amber-500" />
                                            <span>{p.eventName}</span>
                                        </h3>
                                        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
                                            <span className="inline-flex items-center gap-1.5 font-semibold text-amber-700 bg-amber-100 dark:text-amber-300 dark:bg-amber-500/10 px-2 py-0.5 rounded-full">
                                                <TrophyIcon className="w-4 h-4" />
                                                {p.role}
                                            </span>
                                            <span className="inline-flex items-center gap-1.5">
                                                <CalendarDaysIcon className="w-4 h-4 text-slate-400" />
                                                {new Date(p.date).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
                                            </span>
                                        </div>
                                    </div>
                                    <button onClick={() => handleDeleteParticipation(p.id)} className="absolute top-3 left-3 text-slate-400 hover:text-red-600 dark:hover:text-red-500 p-1.5 rounded-full hover:bg-red-50 dark:hover:bg-red-500/10 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="حذف المشاركة">
                                        <TrashIcon className="w-5 h-5" />
                                    </button>
                                </div>
                                <p className="text-slate-600 dark:text-slate-300 mt-3 whitespace-pre-wrap">{p.description}</p>
                            </div>
                        ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    </div>
  );
};

export default ParticipationLogView;