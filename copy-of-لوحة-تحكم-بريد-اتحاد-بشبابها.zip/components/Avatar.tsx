import React from 'react';
import type { EmailAccount } from '../types';
import UserIcon from './icons/UserIcon';

interface AvatarProps {
  account: Partial<EmailAccount>;
  size?: string;
  className?: string;
}

const Avatar: React.FC<AvatarProps> = ({ account, size = 'w-10 h-10', className = '' }) => {
  const getInitials = (name?: string) => {
    if (!name) return '?';
    const names = name.trim().split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  if (account.profilePicture) {
    return (
      <img
        src={account.profilePicture}
        alt={account.fullName || 'Profile'}
        className={`${size} rounded-full object-cover flex-shrink-0 ${className}`}
      />
    );
  }

  return (
    <div
      className={`${size} rounded-full flex items-center justify-center bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-400 font-bold flex-shrink-0 ${className}`}
    >
      {account.fullName ? (
        <span>{getInitials(account.fullName)}</span>
      ) : (
        <UserIcon className="w-1/2 h-1/2" />
      )}
    </div>
  );
};

export default Avatar;