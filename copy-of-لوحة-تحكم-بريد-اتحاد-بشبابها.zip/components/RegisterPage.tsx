import React from 'react';
import type { EmailAccount } from '../types';
import CreateEmailForm from './CreateEmailForm';
import BeShababhaLogo from './icons/YouthUnionLogo.tsx';

interface RegisterPageProps {
  onNavigateToLogin: () => void;
  onAccountCreate: (account: EmailAccount) => void;
  accounts: EmailAccount[];
}

const RegisterPage: React.FC<RegisterPageProps> = ({ onNavigateToLogin, onAccountCreate, accounts }) => {
  const DOMAIN = "youthunion.org";

  return (
    <div className="bg-slate-100 min-h-screen">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <BeShababhaLogo className="w-auto h-12" />
            <div>
              <h1 className="text-xl sm:text-2xl font-bold leading-tight text-slate-900">
                  منصة تسجيل بريد اتحاد بشبابها
              </h1>
            </div>
          </div>
          <button onClick={onNavigateToLogin} className="font-semibold text-amber-600 hover:text-amber-700 text-sm sm:text-base whitespace-nowrap">
            &larr; العودة لتسجيل الدخول
          </button>
        </div>
      </header>
      <main className="py-8 sm:py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <section aria-labelledby="registration-heading">
            <h2 id="registration-heading" className="sr-only">نموذج إنشاء حساب جديد</h2>
            <CreateEmailForm onAccountCreate={onAccountCreate} domain={DOMAIN} accounts={accounts} />
          </section>
        </div>
      </main>
    </div>
  );
};

export default RegisterPage;