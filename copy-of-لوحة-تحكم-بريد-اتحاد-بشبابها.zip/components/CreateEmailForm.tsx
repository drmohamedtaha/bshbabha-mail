import React, { useState, useCallback, useEffect } from 'react';
import type { EmailAccount } from '../types';
import { suggestUsernames } from '../services/geminiService';
import SparklesIcon from './icons/SparklesIcon';
import PlusIcon from './icons/PlusIcon';
import CameraIcon from './icons/CameraIcon';
import Avatar from './Avatar';

interface RegistrationFormProps {
  onAccountCreate: (account: EmailAccount) => Promise<void>;
  domain: string;
  accounts: EmailAccount[];
}

const RegistrationForm: React.FC<RegistrationFormProps> = ({ onAccountCreate, domain, accounts }) => {
  // Personal Info
  const [fullName, setFullName] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [gender, setGender] = useState<'ذكر' | 'أنثى' | ''>('');
  const [maritalStatus, setMaritalStatus] = useState('');
  const [address, setAddress] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [additionalMobileNumber, setAdditionalMobileNumber] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [personalEmail, setPersonalEmail] = useState('');
  const [socialMediaLink, setSocialMediaLink] = useState('');
  const [unionPosition, setUnionPosition] = useState('');

  // Educational Status
  const [qualification, setQualification] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [graduationYear, setGraduationYear] = useState<number | ''>('');
  const [studyStatus, setStudyStatus] = useState<'طالب' | 'خريج' | 'دراسات عليا' | ''>('');
  const [university, setUniversity] = useState('');
  const [gpa, setGpa] = useState('');
  const [trainingCourses, setTrainingCourses] = useState('');
  const [educationSkills, setEducationSkills] = useState('');

  // Professional Status
  const [currentJob, setCurrentJob] = useState('');
  const [employer, setEmployer] = useState('');
  const [jobType, setJobType] = useState<'حكومي' | 'خاص' | 'حر' | 'غير عامل' | ''>('');
  const [yearsOfExperience, setYearsOfExperience] = useState<number | ''>('');
  const [expertiseAreas, setExpertiseAreas] = useState('');
  const [previousProjects, setPreviousProjects] = useState('');
  const [professionalSkills, setProfessionalSkills] = useState('');
  const [availableForVolunteering, setAvailableForVolunteering] = useState(false);
  const [preferredVolunteeringAreas, setPreferredVolunteeringAreas] = useState('');

  // Interests and Abilities
  const [personalSkills, setPersonalSkills] = useState('');
  const [hobbies, setHobbies] = useState('');
  const [interestedInAreas, setInterestedInAreas] = useState('');
  const [strengths, setStrengths] = useState('');
  const [developmentAreas, setDevelopmentAreas] = useState('');

  // Account Details
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const requiredFields = [
      fullName, nationalId, dateOfBirth, governorate, profilePicture, gender,
      maritalStatus, address, mobileNumber, additionalMobileNumber, whatsappNumber,
      personalEmail, socialMediaLink, unionPosition, qualification, specialization,
      graduationYear, studyStatus, university, trainingCourses, educationSkills,
      currentJob, employer, jobType, yearsOfExperience, expertiseAreas,
      previousProjects, professionalSkills, personalSkills, hobbies,
      interestedInAreas, strengths, developmentAreas,
      username, password, confirmPassword
    ];
  
    let filledCount = requiredFields.filter(field => {
      if (typeof field === 'string' || typeof field === 'number') {
        return String(field).trim() !== '';
      }
      return field !== null; // For profilePicture
    }).length;

    let totalCount = requiredFields.length;
  
    if (availableForVolunteering) {
      totalCount++;
      if (preferredVolunteeringAreas.trim() !== '') {
        filledCount++;
      }
    }
  
    const newProgress = totalCount > 0 ? Math.round((filledCount / totalCount) * 100) : 0;
    setProgress(newProgress);
  
  }, [
    fullName, nationalId, dateOfBirth, governorate, profilePicture, gender,
    maritalStatus, address, mobileNumber, additionalMobileNumber, whatsappNumber,
    personalEmail, socialMediaLink, unionPosition, qualification, specialization,
    graduationYear, studyStatus, university, gpa, trainingCourses, educationSkills,
    currentJob, employer, jobType, yearsOfExperience, expertiseAreas,
    previousProjects, professionalSkills, availableForVolunteering, preferredVolunteeringAreas,
    personalSkills, hobbies, interestedInAreas, strengths, developmentAreas,
    username, password, confirmPassword
  ]);

  const handlePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicture(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSuggestUsernames = useCallback(async () => {
    if (!fullName) {
      setError('الرجاء إدخال الاسم الكامل أولاً لاقتراح اسم مستخدم.');
      return;
    }
    setError('');
    setIsLoadingSuggestions(true);
    setSuggestions([]);
    try {
      const result = await suggestUsernames(fullName);
      setSuggestions(result);
    } catch (e) {
      setError('حدث خطأ أثناء اقتراح أسماء المستخدمين.');
    } finally {
      setIsLoadingSuggestions(false);
    }
  }, [fullName]);
  
  const resetForm = () => {
    setFullName(''); setNationalId(''); setDateOfBirth(''); setGovernorate('');
    setProfilePicture(null); setGender(''); setMaritalStatus(''); setAddress('');
    setMobileNumber(''); setAdditionalMobileNumber(''); setWhatsappNumber('');
    setPersonalEmail(''); setSocialMediaLink(''); setUnionPosition('');
    setQualification(''); setSpecialization(''); setGraduationYear('');
    setStudyStatus(''); setUniversity(''); setGpa(''); setTrainingCourses('');
    setEducationSkills(''); setCurrentJob(''); setEmployer(''); setJobType('');
    setYearsOfExperience(''); setExpertiseAreas(''); setPreviousProjects('');
    setProfessionalSkills(''); setAvailableForVolunteering(false);
    setPreferredVolunteeringAreas(''); setPersonalSkills(''); setHobbies('');
    setInterestedInAreas(''); setStrengths(''); setDevelopmentAreas('');
    setUsername(''); setPassword(''); setConfirmPassword('');
    setSuggestions([]); setError('');
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const requiredFields: (string | number | null)[] = [
      fullName, nationalId, dateOfBirth, governorate, profilePicture, gender,
      maritalStatus, address, mobileNumber, additionalMobileNumber, whatsappNumber,
      personalEmail, socialMediaLink, unionPosition, qualification, specialization,
      graduationYear, studyStatus, university, trainingCourses, educationSkills,
      currentJob, employer, jobType, yearsOfExperience, expertiseAreas,
      previousProjects, professionalSkills, personalSkills, hobbies,
      interestedInAreas, strengths, developmentAreas,
      username, password, confirmPassword
    ];
    
    if (requiredFields.some(field => field === '' || field === null)) {
      setError('الرجاء ملء جميع الحقول الإلزامية ورفع صورة شخصية.');
      return;
    }

    if (availableForVolunteering && !preferredVolunteeringAreas) {
        setError('بما أنك اخترت إمكانية التطوع، الرجاء تحديد المجالات التطوعية التي تفضلها.');
        return;
    }

    if (password !== confirmPassword) {
      setError('كلمتا المرور غير متطابقتين.');
      return;
    }
    
    if (password.length < 8) {
        setError('يجب أن لا تقل كلمة المرور عن 8 أحرف.');
        return;
    }

    if (nationalId.length !== 14 || !/^\d+$/.test(nationalId)) {
        setError('الرقم القومي يجب أن يتكون من 14 رقماً.');
        return;
    }
    
    if (accounts.some(acc => acc.nationalId === nationalId)) {
        setError('هذا الرقم القومي مسجل بالفعل في حساب آخر.');
        return;
    }

    if (accounts.some(acc => acc.mobileNumber === mobileNumber)) {
        setError('رقم الموبايل هذا مسجل بالفعل في حساب آخر.');
        return;
    }

    if (accounts.some(acc => acc.username.toLowerCase() === username.toLowerCase())) {
        setError('اسم المستخدم هذا محجوز. الرجاء اختيار اسم آخر.');
        return;
    }

    const newAccount: EmailAccount = {
      id: '', // Will be set by Firebase Auth
      fullName,
      username,
      email: `${username}@${domain}`,
      password,
      createdAt: new Date().toISOString(),
      nationalId,
      dateOfBirth,
      governorate,
      unionPosition,
      mobileNumber,
      whatsappNumber,
      personalEmail,
      profilePicture: profilePicture as string,
      participations: [],
      gender: gender as 'ذكر' | 'أنثى',
      maritalStatus,
      address,
      additionalMobileNumber,
      socialMediaLink,
      qualification,
      specialization,
      graduationYear: Number(graduationYear),
      studyStatus: studyStatus as 'طالب' | 'خريج' | 'دراسات عليا',
      university,
      gpa,
      trainingCourses,
      educationSkills,
      currentJob,
      employer,
      jobType: jobType as 'حكومي' | 'خاص' | 'حر' | 'غير عامل',
      yearsOfExperience: Number(yearsOfExperience),
      expertiseAreas,
      previousProjects,
      professionalSkills,
      availableForVolunteering,
      preferredVolunteeringAreas,
      personalSkills,
      hobbies,
      interestedInAreas,
      strengths,
      developmentAreas,
    };

    setIsSubmitting(true);
    try {
        await onAccountCreate(newAccount);
        // No need to reset form, component will unmount on success
    } catch (error: any) {
        if (error.code === 'auth/email-already-in-use') {
            setError('هذا البريد الإلكتروني (اسم المستخدم) مسجل بالفعل. الرجاء اختيار اسم آخر.');
        } else {
            setError('حدث خطأ غير متوقع أثناء إنشاء الحساب. الرجاء المحاولة مرة أخرى.');
        }
        console.error(error);
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const inputClass = "block w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition";
  const labelClass = "block text-sm font-semibold text-slate-700 mb-2";
  const textareaClass = `${inputClass} resize-y`;
  
  return (
    <div className="bg-white p-8 md:p-10 shadow-2xl rounded-2xl transition-all">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-extrabold text-slate-900 mb-2">إنشاء حساب بريد رسمي</h2>
        <p className="text-slate-500">املأ النموذج التالي لإنشاء بريدك الإلكتروني الرسمي في اتحاد بشبابها.</p>
      </div>

      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-semibold text-slate-600">تقدم التسجيل</span>
          <span className="text-sm font-bold text-amber-600">{progress}% مكتمل</span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-2.5">
          <div 
            className="bg-amber-500 h-2.5 rounded-full transition-all duration-500 ease-out" 
            style={{ width: `${progress}%` }}
            role="progressbar"
            aria-valuenow={progress}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Form completion progress"
          ></div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-10" noValidate>
        
        <details open className="space-y-6 block">
            <summary className="text-xl font-bold text-slate-800 cursor-pointer list-none">
              <div className="text-center">
                <h3>أولاً: البيانات الشخصية الأساسية</h3>
                <hr className="w-24 mx-auto mt-2 border-t-2 border-amber-500"/>
              </div>
            </summary>
            <div className="flex flex-col items-center gap-4 py-4 pt-8">
                <label htmlFor="profilePictureInput" className="cursor-pointer group relative">
                    <Avatar account={{ fullName, profilePicture: profilePicture || undefined }} size="w-32 h-32" className="text-4xl shadow-lg border-4 border-white" />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 rounded-full flex items-center justify-center transition-opacity duration-300">
                        <CameraIcon className="w-10 h-10 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                </label>
                <input type="file" id="profilePictureInput" className="hidden" accept="image/png, image/jpeg, image/webp" onChange={handlePictureChange} required />
                <label htmlFor="profilePictureInput" className="font-semibold text-amber-600 cursor-pointer hover:text-amber-700 text-sm transition-colors">
                  {profilePicture ? 'تغيير الصورة الشخصية' : 'اختر صورة شخصية'}
                </label>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-6">
              <div>
                <label htmlFor="fullName" className={labelClass}>الاسم الكامل</label>
                <input type="text" id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} className={inputClass} placeholder="مثال: أحمد محمد عبدالله" required />
              </div>
              <div>
                <label htmlFor="nationalId" className={labelClass}>الرقم القومي (14 رقم)</label>
                <input type="text" id="nationalId" value={nationalId} onChange={(e) => setNationalId(e.target.value.replace(/\D/g, ''))} maxLength={14} className={`${inputClass} text-left tracking-widest`} placeholder="xxxxxxxxxxxxxx" required />
              </div>
              <div>
                <label htmlFor="dateOfBirth" className={labelClass}>تاريخ الميلاد</label>
                <input type="date" id="dateOfBirth" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} className={inputClass} required />
              </div>
              <div>
                <label htmlFor="gender" className={labelClass}>النوع</label>
                <select id="gender" value={gender} onChange={(e) => setGender(e.target.value as any)} className={inputClass} required>
                  <option value="" disabled>اختر...</option>
                  <option value="ذكر">ذكر</option>
                  <option value="أنثى">أنثى</option>
                </select>
              </div>
              <div>
                <label htmlFor="maritalStatus" className={labelClass}>الحالة الاجتماعية</label>
                <input type="text" id="maritalStatus" value={maritalStatus} onChange={(e) => setMaritalStatus(e.target.value)} className={inputClass} placeholder="أعزب/متزوج" required />
              </div>
              <div>
                <label htmlFor="governorate" className={labelClass}>المحافظة</label>
                <input type="text" id="governorate" value={governorate} onChange={(e) => setGovernorate(e.target.value)} className={inputClass} placeholder="مثال: القاهرة" required />
              </div>
              <div className="md:col-span-3">
                <label htmlFor="address" className={labelClass}>العنوان بالتفصيل</label>
                <input type="text" id="address" value={address} onChange={(e) => setAddress(e.target.value)} className={inputClass} placeholder="المحافظة – المركز/المدينة – القرية/الحي – الشارع – رقم العقار" required />
              </div>
              <div>
                <label htmlFor="mobileNumber" className={labelClass}>رقم الموبايل</label>
                <input type="tel" id="mobileNumber" value={mobileNumber} onChange={(e) => setMobileNumber(e.target.value)} className={`${inputClass} text-left`} placeholder="01xxxxxxxxx" required />
              </div>
               <div>
                <label htmlFor="additionalMobileNumber" className={labelClass}>رقم هاتف إضافي</label>
                <input type="tel" id="additionalMobileNumber" value={additionalMobileNumber} onChange={(e) => setAdditionalMobileNumber(e.target.value)} className={`${inputClass} text-left`} placeholder="01xxxxxxxxx" required />
              </div>
              <div>
                <label htmlFor="whatsappNumber" className={labelClass}>رقم الواتس اب</label>
                <input type="tel" id="whatsappNumber" value={whatsappNumber} onChange={(e) => setWhatsappNumber(e.target.value)} className={`${inputClass} text-left`} placeholder="01xxxxxxxxx" required />
              </div>
              <div className="md:col-span-2">
                <label htmlFor="personalEmail" className={labelClass}>الإيميل الشخصي</label>
                <input type="email" id="personalEmail" value={personalEmail} onChange={(e) => setPersonalEmail(e.target.value)} className={`${inputClass} text-left`} placeholder="example@domain.com" required />
              </div>
               <div>
                <label htmlFor="unionPosition" className={labelClass}>الصفة في الاتحاد</label>
                <input type="text" id="unionPosition" value={unionPosition} onChange={(e) => setUnionPosition(e.target.value)} className={inputClass} placeholder="مثال: عضو لجنة" required />
              </div>
               <div className="md:col-span-3">
                <label htmlFor="socialMediaLink" className={labelClass}>رابط فيسبوك / انستجرام</label>
                <input type="url" id="socialMediaLink" value={socialMediaLink} onChange={(e) => setSocialMediaLink(e.target.value)} className={`${inputClass} text-left`} placeholder="https://facebook.com/username" required />
              </div>
            </div>
        </details>

        <details className="space-y-6 block">
            <summary className="text-xl font-bold text-slate-800 cursor-pointer list-none">
              <div className="text-center">
                <h3>ثانياً: الحالة التعليمية</h3>
                <hr className="w-24 mx-auto mt-2 border-t-2 border-amber-500"/>
              </div>
            </summary>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6 pt-8">
              <div>
                <label htmlFor="qualification" className={labelClass}>المؤهل الدراسي</label>
                <input type="text" id="qualification" value={qualification} onChange={(e) => setQualification(e.target.value)} className={inputClass} required />
              </div>
              <div>
                <label htmlFor="specialization" className={labelClass}>التخصص</label>
                <input type="text" id="specialization" value={specialization} onChange={(e) => setSpecialization(e.target.value)} className={inputClass} required />
              </div>
              <div>
                <label htmlFor="graduationYear" className={labelClass}>سنة التخرج</label>
                <input type="number" id="graduationYear" value={graduationYear} onChange={(e) => setGraduationYear(e.target.valueAsNumber || '')} className={inputClass} placeholder="YYYY" required />
              </div>
              <div>
                <label htmlFor="studyStatus" className={labelClass}>الحالة الدراسية</label>
                <select id="studyStatus" value={studyStatus} onChange={(e) => setStudyStatus(e.target.value as any)} className={inputClass} required>
                  <option value="" disabled>اختر...</option>
                  <option value="طالب">طالب</option>
                  <option value="خريج">خريج</option>
                  <option value="دراسات عليا">دراسات عليا</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label htmlFor="university" className={labelClass}>الجامعة/المدرسة</label>
                <input type="text" id="university" value={university} onChange={(e) => setUniversity(e.target.value)} className={inputClass} required />
              </div>
               <div>
                <label htmlFor="gpa" className={labelClass}>معدل/تقدير التخرج (اختياري)</label>
                <input type="text" id="gpa" value={gpa} onChange={(e) => setGpa(e.target.value)} className={inputClass} />
              </div>
               <div className="md:col-span-2">
                <label htmlFor="trainingCourses" className={labelClass}>دورات تدريبية معتمدة</label>
                <textarea id="trainingCourses" value={trainingCourses} onChange={(e) => setTrainingCourses(e.target.value)} rows={3} className={textareaClass} required></textarea>
              </div>
               <div className="md:col-span-2">
                <label htmlFor="educationSkills" className={labelClass}>المهارات المرتبطة بالتعليم (لغات، حاسوب، برامج… إلخ)</label>
                <textarea id="educationSkills" value={educationSkills} onChange={(e) => setEducationSkills(e.target.value)} rows={3} className={textareaClass} required></textarea>
              </div>
            </div>
        </details>
        
        <details className="space-y-6 block">
            <summary className="text-xl font-bold text-slate-800 cursor-pointer list-none">
              <div className="text-center">
                <h3>ثالثاً: الحالة الوظيفية</h3>
                <hr className="w-24 mx-auto mt-2 border-t-2 border-amber-500"/>
              </div>
            </summary>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6 pt-8">
                <div>
                  <label htmlFor="currentJob" className={labelClass}>الوظيفة الحالية</label>
                  <input type="text" id="currentJob" value={currentJob} onChange={(e) => setCurrentJob(e.target.value)} className={inputClass} required />
                </div>
                <div>
                  <label htmlFor="employer" className={labelClass}>جهة العمل</label>
                  <input type="text" id="employer" value={employer} onChange={(e) => setEmployer(e.target.value)} className={inputClass} required />
                </div>
                <div>
                  <label htmlFor="jobType" className={labelClass}>طبيعة العمل</label>
                  <select id="jobType" value={jobType} onChange={(e) => setJobType(e.target.value as any)} className={inputClass} required>
                    <option value="" disabled>اختر...</option>
                    <option value="حكومي">حكومي</option>
                    <option value="خاص">خاص</option>
                    <option value="حر">حر</option>
                    <option value="غير عامل">غير عامل</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="yearsOfExperience" className={labelClass}>سنوات الخبرة</label>
                  <input type="number" id="yearsOfExperience" min="0" value={yearsOfExperience} onChange={(e) => setYearsOfExperience(e.target.valueAsNumber || '')} className={inputClass} required />
                </div>
                <div className="md:col-span-2">
                  <label htmlFor="expertiseAreas" className={labelClass}>مجالات الخبرة الأساسية</label>
                  <textarea id="expertiseAreas" value={expertiseAreas} onChange={(e) => setExpertiseAreas(e.target.value)} rows={3} className={textareaClass} required></textarea>
                </div>
                <div className="md:col-span-2">
                  <label htmlFor="previousProjects" className={labelClass}>المشاريع السابقة التي شاركت فيها</label>
                  <textarea id="previousProjects" value={previousProjects} onChange={(e) => setPreviousProjects(e.target.value)} rows={3} className={textareaClass} required></textarea>
                </div>
                 <div className="md:col-span-2">
                  <label htmlFor="professionalSkills" className={labelClass}>المهارات المهنية</label>
                  <textarea id="professionalSkills" value={professionalSkills} onChange={(e) => setProfessionalSkills(e.target.value)} rows={3} className={textareaClass} required></textarea>
                </div>
                <div className="md:col-span-2 space-y-4">
                    <div className="flex items-center gap-3">
                        <input type="checkbox" id="availableForVolunteering" checked={availableForVolunteering} onChange={(e) => setAvailableForVolunteering(e.target.checked)} className="w-4 h-4 text-amber-600 border-slate-300 rounded focus:ring-amber-500"/>
                        <label htmlFor="availableForVolunteering" className="font-semibold text-slate-700">إمكانية العمل التطوعي</label>
                    </div>
                    {availableForVolunteering && (
                      <div>
                        <label htmlFor="preferredVolunteeringAreas" className={labelClass}>المجالات التطوعية التي تفضلها</label>
                        <textarea id="preferredVolunteeringAreas" value={preferredVolunteeringAreas} onChange={(e) => setPreferredVolunteeringAreas(e.target.value)} rows={3} className={textareaClass} required={availableForVolunteering}></textarea>
                      </div>
                    )}
                </div>
            </div>
        </details>
        
        <details className="space-y-6 block">
            <summary className="text-xl font-bold text-slate-800 cursor-pointer list-none">
              <div className="text-center">
                <h3>خامساً: اهتمامات العضو وقدراته</h3>
                <hr className="w-24 mx-auto mt-2 border-t-2 border-amber-500"/>
              </div>
            </summary>
            <div className="space-y-6 pt-8">
              <div>
                  <label htmlFor="personalSkills" className={labelClass}>المهارات الشخصية (قيادة – تواصل – إدارة وقت – عمل جماعي…)</label>
                  <textarea id="personalSkills" value={personalSkills} onChange={(e) => setPersonalSkills(e.target.value)} rows={3} className={textareaClass} required></textarea>
              </div>
               <div>
                  <label htmlFor="hobbies" className={labelClass}>الهوايات والأنشطة المفضلة</label>
                  <textarea id="hobbies" value={hobbies} onChange={(e) => setHobbies(e.target.value)} rows={3} className={textareaClass} required></textarea>
              </div>
               <div>
                  <label htmlFor="interestedInAreas" className={labelClass}>المجالات التي ترغب في المشاركة فيها داخل الاتحاد</label>
                  <textarea id="interestedInAreas" value={interestedInAreas} onChange={(e) => setInterestedInAreas(e.target.value)} rows={3} className={textareaClass} placeholder="ثقافية – اجتماعية – رياضية – خيرية – إعلامية – سياسية – تقنية – ابتكار – تدريب وتنمية" required></textarea>
              </div>
               <div>
                  <label htmlFor="strengths" className={labelClass}>أهم نقاط القوة لديك</label>
                  <textarea id="strengths" value={strengths} onChange={(e) => setStrengths(e.target.value)} rows={3} className={textareaClass} required></textarea>
              </div>
               <div>
                  <label htmlFor="developmentAreas" className={labelClass}>نقاط ترغب في تطويرها</label>
                  <textarea id="developmentAreas" value={developmentAreas} onChange={(e) => setDevelopmentAreas(e.target.value)} rows={3} className={textareaClass} required></textarea>
              </div>
            </div>
        </details>

        <details open className="space-y-6 block">
            <summary className="text-xl font-bold text-slate-800 cursor-pointer list-none">
              <div className="text-center">
                <h3>أخيراً: بيانات الحساب</h3>
                <hr className="w-24 mx-auto mt-2 border-t-2 border-amber-500"/>
              </div>
            </summary>
            <div className="space-y-6 pt-8">
                <div>
                  <label htmlFor="username" className={labelClass}>اسم المستخدم (باللغة الإنجليزية)</label>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <div className="flex-grow flex items-center bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus-within:ring-2 focus-within:ring-amber-500 overflow-hidden transition">
                        <input type="text" id="username" value={username} onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._-]/g, ''))} className="flex-grow w-full px-4 py-3 border-0 focus:outline-none focus:ring-0 bg-transparent text-left" placeholder="مثال: ahmed.abdullah" required />
                        <span className="px-4 bg-slate-200 text-slate-500 self-stretch flex items-center border-r border-slate-300 font-mono text-sm">@{domain}</span>
                    </div>
                    <button type="button" onClick={handleSuggestUsernames} disabled={isLoadingSuggestions || !fullName} className="flex-shrink-0 flex items-center justify-center gap-2 bg-amber-100 text-amber-800 hover:bg-amber-200 font-bold px-4 py-3 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm" aria-label="اقترح اسم مستخدم">
                      {isLoadingSuggestions ? (<div className="w-5 h-5 border-2 border-amber-300 border-t-amber-600 rounded-full animate-spin"></div>) : (<SparklesIcon className="w-5 h-5" />)}
                      <span>اقتراح</span>
                    </button>
                  </div>
                  {suggestions.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2 items-center">
                      <p className="text-sm text-slate-600">مقترحات:</p>
                      {suggestions.map((s) => ( <button key={s} type="button" onClick={() => setUsername(s)} className="px-3 py-1 bg-amber-50 text-amber-800 rounded-full text-sm font-mono hover:bg-amber-100 border border-amber-200 transition">{s}</button>))}
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
                    <div>
                        <label htmlFor="password" className={labelClass}>كلمة المرور</label>
                        <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} className={inputClass} placeholder="••••••••" required />
                    </div>
                    <div>
                        <label htmlFor="confirmPassword" className={labelClass}>تأكيد كلمة المرور</label>
                        <input type="password" id="confirmPassword" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className={inputClass} placeholder="••••••••" required />
                    </div>
                </div>
            </div>
        </details>
        
        {error && (
          <div className="bg-red-50 border-r-4 border-red-500 p-4 text-red-800 rounded-lg shadow-md" role="alert">
            <p className="font-bold">حدث خطأ</p>
            <p>{error}</p>
          </div>
        )}

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button type="submit" disabled={isSubmitting} className="w-full sm:w-auto flex items-center justify-center gap-2 bg-amber-500 text-white font-extrabold text-lg px-10 py-4 rounded-lg hover:bg-amber-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed">
            {isSubmitting ? (
              <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <PlusIcon className="w-6 h-6" />
            )}
            <span>{isSubmitting ? 'جاري الإنشاء...' : 'إنشاء الحساب'}</span>
          </button>
           <button type="button" onClick={resetForm} className="w-full sm:w-auto text-sm text-slate-600 hover:text-slate-800 hover:bg-slate-100 px-4 py-2 rounded-lg transition">
            مسح النموذج
          </button>
        </div>
      </form>
    </div>
  );
};

export default RegistrationForm;
