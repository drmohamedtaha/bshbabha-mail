import React from 'react';
import CloudIcon from './icons/CloudIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import ExclamationCircleIcon from './icons/ExclamationCircleIcon';

export type SyncStatus = 'idle' | 'syncing' | 'saved' | 'error';

interface SyncStatusIndicatorProps {
  status: SyncStatus;
}

const SyncStatusIndicator: React.FC<SyncStatusIndicatorProps> = ({ status }) => {
  
  const getStatusContent = () => {
    switch (status) {
      case 'syncing':
        return {
          icon: <div className="w-5 h-5 border-2 border-slate-400 border-t-slate-600 rounded-full animate-spin"></div>,
          text: 'جاري المزامنة...',
          color: 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300',
        };
      case 'saved':
        return {
          icon: <CheckCircleIcon className="w-5 h-5 text-green-500" />,
          text: 'تم الحفظ',
          color: 'bg-green-50 dark:bg-green-900/50 text-green-700 dark:text-green-300',
        };
      case 'error':
        return {
          icon: <ExclamationCircleIcon className="w-5 h-5 text-red-500" />,
          text: 'خطأ في الحفظ',
          color: 'bg-red-50 dark:bg-red-900/50 text-red-700 dark:text-red-300',
        };
      case 'idle':
      default:
         return {
          icon: <CloudIcon className="w-5 h-5 text-slate-400" />,
          text: 'متصل',
          color: 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400',
        };
    }
  };
  
  const content = getStatusContent();

  return (
    <div className={`fixed bottom-4 left-4 z-50 transition-all duration-300 ease-in-out ${status !== 'idle' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'}`}>
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold shadow-md border border-black/5 ${content.color}`}>
            {content.icon}
            <span>{content.text}</span>
        </div>
    </div>
  );
};

export default SyncStatusIndicator;
