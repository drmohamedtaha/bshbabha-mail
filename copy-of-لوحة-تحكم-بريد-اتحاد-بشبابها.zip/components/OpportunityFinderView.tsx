import React, { useState } from 'react';
import type { EmailAccount, CandidateMatch } from '../types';
import LightBulbIcon from './icons/LightBulbIcon';
import Avatar from './Avatar';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';
import PencilIcon from './icons/PencilIcon';
import EditAccountModal from './EditAccountModal';

interface OpportunityFinderViewProps {
  onFindCandidates: (description: string) => void;
  isLoading: boolean;
  results: CandidateMatch[];
  accounts: EmailAccount[];
  error: string;
  onComposeMessage: (recipient?: string) => void;
  onUpdateAccount: (account: EmailAccount) => void;
}

const OpportunityFinderView: React.FC<OpportunityFinderViewProps> = ({
  onFindCandidates,
  isLoading,
  results,
  accounts,
  error,
  onComposeMessage,
  onUpdateAccount
}) => {
  const [description, setDescription] = useState('');
  const [editingAccount, setEditingAccount] = useState<EmailAccount | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    onFindCandidates(description);
  };

  const getAccountById = (id: string) => accounts.find(acc => acc.id === id);

  return (
    <>
      <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
        <header className="text-center mb-8">
          <LightBulbIcon className="w-16 h-16 mx-auto text-amber-400" />
          <h1 className="text-3xl font-extrabold text-slate-900 mt-4">البحث الذكي عن الكفاءات</h1>
          <p className="text-slate-500 mt-2 max-w-2xl mx-auto">
            صف متطلبات الفرصة أو المشروع، وسيقوم الذكاء الاصطناعي بتحليل بيانات جميع الأعضاء لاقتراح أفضل المرشحين لك.
          </p>
        </header>

        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto">
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            className="w-full p-4 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition text-lg"
            placeholder="مثال: نبحث عن عضو لديه خبرة في تنظيم الفعاليات، يجيد التحدث أمام الجمهور، ومتاح للتطوع في عطلة نهاية الأسبوع..."
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !description.trim()}
            className="mt-4 w-full flex items-center justify-center gap-3 bg-amber-500 text-white font-bold py-4 px-6 rounded-lg hover:bg-amber-600 transition-colors shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>جاري التحليل...</span>
              </>
            ) : (
              <>
                <LightBulbIcon className="w-6 h-6" />
                <span>ابحث عن المرشحين</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-12">
          {error && (
            <div className="bg-red-50 border-r-4 border-red-500 p-4 text-red-800 rounded-lg shadow-md max-w-3xl mx-auto" role="alert">
              <p className="font-bold">حدث خطأ</p>
              <p>{error}</p>
            </div>
          )}

          {!isLoading && results.length > 0 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-center text-slate-800">المرشحون المقترحون</h2>
              {results.map(match => {
                const account = getAccountById(match.accountId);
                if (!account) return null;

                return (
                  <div key={match.accountId} className="bg-slate-50 p-5 rounded-xl border border-slate-200 shadow-sm max-w-4xl mx-auto">
                    <div className="flex flex-col sm:flex-row items-start gap-5">
                      <div className="flex-shrink-0 flex flex-col items-center w-full sm:w-40">
                        <Avatar account={account} size="w-24 h-24" />
                        <h3 className="text-lg font-bold text-slate-800 mt-2 text-center">{account.fullName}</h3>
                        <p className="text-sm text-slate-500">{account.unionPosition}</p>
                         <div className="w-full bg-slate-200 rounded-full h-2.5 mt-3">
                            <div
                                className="bg-green-500 h-2.5 rounded-full"
                                style={{ width: `${match.matchPercentage}%` }}
                            ></div>
                        </div>
                        <p className="text-xs font-bold text-green-700 mt-1">مطابقة بنسبة {match.matchPercentage}%</p>
                      </div>

                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-700">سبب الترشيح:</h4>
                        <div
                          className="prose prose-sm text-slate-600 mt-1 whitespace-pre-wrap"
                          dangerouslySetInnerHTML={{ __html: match.reasoning.replace(/•/g, '<br/>&bull;') }}
                        ></div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
                         <button
                            onClick={() => setEditingAccount(account)}
                            className="flex items-center gap-2 text-sm bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2 rounded-lg transition-colors"
                         >
                            <PencilIcon className="w-4 h-4" />
                            <span>عرض الملف</span>
                         </button>
                         <button
                           onClick={() => onComposeMessage(account.email)}
                           className="flex items-center gap-2 text-sm bg-green-500 hover:bg-green-600 text-white font-semibold px-4 py-2 rounded-lg transition-colors"
                         >
                            <PaperAirplaneIcon className="w-4 h-4" />
                            <span>إرسال رسالة</span>
                         </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          
          {!isLoading && results.length === 0 && !error && (
            <div className="text-center py-10 text-slate-400 max-w-3xl mx-auto">
                 <p>سيتم عرض نتائج البحث هنا.</p>
            </div>
          )}
        </div>
      </div>
      {editingAccount && (
        <EditAccountModal
          isOpen={!!editingAccount}
          onClose={() => setEditingAccount(null)}
          account={editingAccount}
          onUpdateAccount={onUpdateAccount}
          domain={editingAccount.email.split('@')[1]}
        />
      )}
    </>
  );
};

export default OpportunityFinderView;
