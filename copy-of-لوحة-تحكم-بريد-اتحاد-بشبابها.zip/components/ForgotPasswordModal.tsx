import React, { useState } from 'react';
import CloseIcon from './icons/CloseIcon';

interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPasswordReset: (personalEmail: string) => Promise<void>;
}

const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ isOpen, onClose, onPasswordReset }) => {
  const [email, setEmail] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleClose = () => {
    setEmail('');
    setIsSent(false);
    setError('');
    setIsLoading(false);
    onClose();
  };
  
  const handleSubmit = async () => {
    setError('');
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setError('الرجاء إدخال بريد إلكتروني شخصي صحيح.');
      return;
    }
    
    setIsLoading(true);
    try {
        await onPasswordReset(email);
        setIsSent(true);
    } catch(e: any) {
        console.error("Password reset error:", e);
        if (e.code === 'auth/user-not-found') {
            // Don't tell the user if the email exists or not for security reasons.
            // Just show the success message.
            setIsSent(true); 
        } else {
            setError('حدث خطأ أثناء محاولة إرسال البريد. الرجاء المحاولة مرة أخرى.');
        }
    } finally {
        setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm" onClick={handleClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md transform transition-all" onClick={(e) => e.stopPropagation()}>
        <header className="p-5 border-b border-slate-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800">
              {isSent ? 'تم الإرسال' : 'استعادة كلمة المرور'}
            </h2>
            <button onClick={handleClose} className="text-slate-400 hover:text-slate-600" aria-label="إغلاق">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>

        <main className="p-6">
          {isSent ? (
            <div className="space-y-4">
              <p className="text-slate-600 text-center">
                إذا كان بريدك الإلكتروني الشخصي مسجلاً لدينا، فستصلك رسالة تحتوي على رابط لإعادة تعيين كلمة المرور الخاصة بك.
              </p>
            </div>
          ) : (
            <div>
              <p className="text-slate-600 mb-4">
                أدخل بريدك الإلكتروني الشخصي المسجل بالحساب. سنقوم بإرسال رابط إعادة تعيين كلمة المرور إليه.
              </p>
              <div className="space-y-4">
                <div>
                  <label htmlFor="recovery-email" className="block text-sm font-medium text-slate-700 mb-1">البريد الإلكتروني الشخصي</label>
                  <input 
                    type="email" 
                    id="recovery-email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" 
                    placeholder="example@domain.com"
                    required 
                    disabled={isLoading}
                  />
                </div>
              </div>
              {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
            </div>
          )}
        </main>
        
        <footer className="bg-slate-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200">
          <button onClick={handleClose} className="bg-slate-200 text-slate-700 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 transition-colors" disabled={isLoading}>
            {isSent ? 'إغلاق' : 'إلغاء'}
          </button>
          {!isSent && (
            <button
              onClick={handleSubmit}
              className="bg-amber-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-amber-600 transition-colors flex items-center justify-center w-28 shadow-sm hover:shadow-md"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                'إرسال'
              )}
            </button>
          )}
        </footer>
      </div>
    </div>
  );
};

export default ForgotPasswordModal;
