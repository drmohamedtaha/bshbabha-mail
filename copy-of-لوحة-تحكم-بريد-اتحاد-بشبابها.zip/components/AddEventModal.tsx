import React, { useState } from 'react';
import CloseIcon from './icons/CloseIcon';
import CalendarDaysIcon from './icons/CalendarDaysIcon';

interface AddEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateEvent: (event: { name: string; date: string; location: string; description: string; }) => void;
}

const AddEventModal: React.FC<AddEventModalProps> = ({ isOpen, onClose, onCreateEvent }) => {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    setError('');
    if (!name || !date || !location || !description) {
      setError('الرجاء ملء جميع حقول الفاعلية.');
      return;
    }
    onCreateEvent({ name, date, location, description });
    setName('');
    setDate('');
    setLocation('');
    setDescription('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all" onClick={(e) => e.stopPropagation()}>
        <header className="p-5 border-b border-slate-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-3">
              <CalendarDaysIcon className="w-6 h-6 text-teal-500" />
              إضافة فاعلية جديدة
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>
        <main className="p-6">
          <p className="text-slate-600 mb-6">
            سيتم إرسال دعوة لهذه الفاعلية إلى جميع الأعضاء المسجلين.
          </p>
          <div className="space-y-4">
            <div>
              <label htmlFor="event-name" className="block text-sm font-medium text-slate-700 mb-1">اسم الفاعلية</label>
              <input type="text" id="event-name" value={name} onChange={(e) => setName(e.target.value)} className="w-full px-4 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="event-date" className="block text-sm font-medium text-slate-700 mb-1">تاريخ الفاعلية</label>
                    <input type="date" id="event-date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full px-4 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
                </div>
                 <div>
                    <label htmlFor="event-location" className="block text-sm font-medium text-slate-700 mb-1">مكان الفاعلية</label>
                    <input type="text" id="event-location" value={location} onChange={(e) => setLocation(e.target.value)} className="w-full px-4 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
                </div>
            </div>
            <div>
              <label htmlFor="event-description" className="block text-sm font-medium text-slate-700 mb-1">وصف الفاعلية</label>
              <textarea id="event-description" value={description} onChange={(e) => setDescription(e.target.value)} rows={5} className="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required></textarea>
            </div>
          </div>
          {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
        </main>
        <footer className="bg-slate-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200">
          <button onClick={onClose} className="bg-slate-200 text-slate-700 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 transition-colors">إلغاء</button>
          <button onClick={handleSubmit} className="bg-teal-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-teal-600 transition-colors shadow-sm hover:shadow-md">إنشاء وإرسال الدعوات</button>
        </footer>
      </div>
    </div>
  );
};

export default AddEventModal;
