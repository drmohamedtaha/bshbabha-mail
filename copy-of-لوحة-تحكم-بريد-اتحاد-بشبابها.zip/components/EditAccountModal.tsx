import React, { useState, useEffect } from 'react';
import type { EmailAccount } from '../types';
import CloseIcon from './icons/CloseIcon';
import PencilIcon from './icons/PencilIcon';
import Avatar from './Avatar';
import CameraIcon from './icons/CameraIcon';

interface EditAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: EmailAccount;
  onUpdateAccount: (account: EmailAccount) => void;
  domain: string;
}

const EditAccountModal: React.FC<EditAccountModalProps> = ({ isOpen, onClose, account, onUpdateAccount, domain }) => {
  const [formData, setFormData] = useState<Partial<EmailAccount>>({});
  const [error, setError] = useState('');

  useEffect(() => {
    if (account) {
      setFormData(account);
    }
  }, [account]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value, type } = e.target;
     if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [id]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [id]: value }));
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            setFormData(prev => ({ ...prev, profilePicture: reader.result as string }));
        };
        reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.nationalId && (formData.nationalId.length !== 14 || !/^\d+$/.test(formData.nationalId))) {
      setError('الرقم القومي يجب أن يتكون من 14 رقماً.');
      return;
    }

    onUpdateAccount({ ...account, ...formData, email: `${formData.username}@${domain}` });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl transform transition-all" onClick={(e) => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <header className="p-5 border-b border-slate-200">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800 flex items-center gap-3">
                <PencilIcon className="w-6 h-6 text-amber-600" />
                تعديل بيانات: {account.fullName}
              </h2>
              <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
                <CloseIcon className="w-6 h-6" />
              </button>
            </div>
          </header>
            
          <main className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
            <details open className="space-y-4">
                <summary className="text-lg font-semibold text-slate-800 cursor-pointer">أولاً: البيانات الشخصية الأساسية</summary>
                <div className="flex flex-col items-center gap-4 py-4">
                    <label htmlFor="editProfilePictureInput" className="cursor-pointer group relative">
                        <Avatar account={formData} size="w-24 h-24" className="text-2xl shadow-md border-2 border-white" />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 rounded-full flex items-center justify-center transition-opacity">
                            <CameraIcon className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                    </label>
                    <input type="file" id="editProfilePictureInput" className="hidden" accept="image/png, image/jpeg, image/webp" onChange={handleFileChange}/>
                    <p className="text-sm text-slate-500">تغيير الصورة الشخصية</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                    <div>
                        <label htmlFor="fullName" className="block text-sm font-medium text-slate-700 mb-1">الاسم الكامل</label>
                        <input type="text" id="fullName" value={formData.fullName || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="username" className="block text-sm font-medium text-slate-700 mb-1">اسم المستخدم</label>
                        <input type="text" id="username" value={formData.username || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="nationalId" className="block text-sm font-medium text-slate-700 mb-1">الرقم القومي</label>
                        <input type="text" id="nationalId" value={formData.nationalId || ''} onChange={handleChange} maxLength={14} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="dateOfBirth" className="block text-sm font-medium text-slate-700 mb-1">تاريخ الميلاد</label>
                        <input type="date" id="dateOfBirth" value={formData.dateOfBirth || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="gender" className="block text-sm font-medium text-slate-700 mb-1">النوع</label>
                        <select id="gender" value={formData.gender || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm">
                            <option value="">اختر...</option>
                            <option value="ذكر">ذكر</option>
                            <option value="أنثى">أنثى</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="maritalStatus" className="block text-sm font-medium text-slate-700 mb-1">الحالة الاجتماعية</label>
                        <input type="text" id="maritalStatus" value={formData.maritalStatus || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div className="lg:col-span-3">
                        <label htmlFor="address" className="block text-sm font-medium text-slate-700 mb-1">العنوان بالتفصيل</label>
                        <input type="text" id="address" value={formData.address || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="governorate" className="block text-sm font-medium text-slate-700 mb-1">المحافظة</label>
                        <input type="text" id="governorate" value={formData.governorate || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="mobileNumber" className="block text-sm font-medium text-slate-700 mb-1">رقم الموبايل</label>
                        <input type="tel" id="mobileNumber" value={formData.mobileNumber || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div>
                        <label htmlFor="additionalMobileNumber" className="block text-sm font-medium text-slate-700 mb-1">رقم هاتف إضافي</label>
                        <input type="tel" id="additionalMobileNumber" value={formData.additionalMobileNumber || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="whatsappNumber" className="block text-sm font-medium text-slate-700 mb-1">رقم الواتس اب</label>
                        <input type="tel" id="whatsappNumber" value={formData.whatsappNumber || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" />
                    </div>
                     <div className="lg:col-span-2">
                        <label htmlFor="personalEmail" className="block text-sm font-medium text-slate-700 mb-1">الإيميل الشخصي</label>
                        <input type="email" id="personalEmail" value={formData.personalEmail || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                    <div className="lg:col-span-3">
                        <label htmlFor="socialMediaLink" className="block text-sm font-medium text-slate-700 mb-1">رابط فيسبوك / انستجرام</label>
                        <input type="text" id="socialMediaLink" value={formData.socialMediaLink || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                </div>
            </details>

            <details className="space-y-4 pt-4 border-t">
                <summary className="text-lg font-semibold text-slate-800 cursor-pointer">ثانياً: الحالة التعليمية</summary>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                    <div>
                        <label htmlFor="qualification" className="block text-sm font-medium text-slate-700 mb-1">المؤهل الدراسي</label>
                        <input type="text" id="qualification" value={formData.qualification || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                     <div>
                        <label htmlFor="specialization" className="block text-sm font-medium text-slate-700 mb-1">التخصص</label>
                        <input type="text" id="specialization" value={formData.specialization || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="graduationYear" className="block text-sm font-medium text-slate-700 mb-1">سنة التخرج</label>
                        <input type="number" id="graduationYear" value={formData.graduationYear || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="studyStatus" className="block text-sm font-medium text-slate-700 mb-1">الحالة الدراسية</label>
                         <select id="studyStatus" value={formData.studyStatus || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm">
                            <option value="">اختر...</option>
                            <option value="طالب">طالب</option>
                            <option value="خريج">خريج</option>
                            <option value="دراسات عليا">دراسات عليا</option>
                        </select>
                    </div>
                    <div className="lg:col-span-2">
                        <label htmlFor="university" className="block text-sm font-medium text-slate-700 mb-1">الجامعة/المدرسة</label>
                        <input type="text" id="university" value={formData.university || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div className="lg:col-span-3">
                        <label htmlFor="trainingCourses" className="block text-sm font-medium text-slate-700 mb-1">دورات تدريبية معتمدة</label>
                        <textarea id="trainingCourses" value={formData.trainingCourses || ''} onChange={handleChange} rows={3} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"></textarea>
                    </div>
                </div>
            </details>

            <details className="space-y-4 pt-4 border-t">
                <summary className="text-lg font-semibold text-slate-800 cursor-pointer">ثالثاً: الحالة الوظيفية</summary>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                     <div>
                        <label htmlFor="currentJob" className="block text-sm font-medium text-slate-700 mb-1">الوظيفة الحالية</label>
                        <input type="text" id="currentJob" value={formData.currentJob || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                     <div>
                        <label htmlFor="employer" className="block text-sm font-medium text-slate-700 mb-1">جهة العمل</label>
                        <input type="text" id="employer" value={formData.employer || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="jobType" className="block text-sm font-medium text-slate-700 mb-1">طبيعة العمل</label>
                         <select id="jobType" value={formData.jobType || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm">
                            <option value="">اختر...</option>
                            <option value="حكومي">حكومي</option>
                            <option value="خاص">خاص</option>
                            <option value="حر">حر</option>
                            <option value="غير عامل">غير عامل</option>
                        </select>
                    </div>
                    <div className="lg:col-span-3">
                        <label htmlFor="professionalSkills" className="block text-sm font-medium text-slate-700 mb-1">المهارات المهنية</label>
                        <textarea id="professionalSkills" value={formData.professionalSkills || ''} onChange={handleChange} rows={3} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"></textarea>
                    </div>
                    <div className="flex items-center gap-3 pt-2">
                         <input type="checkbox" id="availableForVolunteering" checked={formData.availableForVolunteering || false} onChange={handleChange} className="w-4 h-4 text-amber-600 border-slate-300 rounded focus:ring-amber-500"/>
                        <label htmlFor="availableForVolunteering" className="block text-sm font-medium text-slate-700">إمكانية العمل التطوعي</label>
                    </div>
                </div>
            </details>
            
            <details className="space-y-4 pt-4 border-t">
                <summary className="text-lg font-semibold text-slate-800 cursor-pointer">خامساً: اهتمامات العضو وقدراته</summary>
                <div className="grid grid-cols-1 gap-4">
                    <div>
                        <label htmlFor="personalSkills" className="block text-sm font-medium text-slate-700 mb-1">المهارات الشخصية (قيادة، تواصل...)</label>
                        <textarea id="personalSkills" value={formData.personalSkills || ''} onChange={handleChange} rows={3} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"></textarea>
                    </div>
                     <div>
                        <label htmlFor="hobbies" className="block text-sm font-medium text-slate-700 mb-1">الهوايات والأنشطة المفضلة</label>
                        <textarea id="hobbies" value={formData.hobbies || ''} onChange={handleChange} rows={3} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"></textarea>
                    </div>
                </div>
            </details>

            <details className="space-y-4 pt-4 border-t">
                <summary className="text-lg font-semibold text-slate-800 cursor-pointer">سادساً: بيانات العضوية داخل الاتحاد (للمسؤول)</summary>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                     <div>
                        <label htmlFor="unionPosition" className="block text-sm font-medium text-slate-700 mb-1">الصفة في الاتحاد</label>
                        <input type="text" id="unionPosition" value={formData.unionPosition || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm" required />
                    </div>
                     <div>
                        <label htmlFor="committee" className="block text-sm font-medium text-slate-700 mb-1">اللجنة أو الفريق</label>
                        <input type="text" id="committee" value={formData.committee || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="commitmentRating" className="block text-sm font-medium text-slate-700 mb-1">تقييم الالتزام (1-5)</label>
                        <input type="number" id="commitmentRating" min="1" max="5" value={formData.commitmentRating || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"/>
                    </div>
                    <div>
                        <label htmlFor="availability" className="block text-sm font-medium text-slate-700 mb-1">مدى التوافر</label>
                         <select id="availability" value={formData.availability || ''} onChange={handleChange} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm">
                            <option value="">اختر...</option>
                            <option value="يوميًا">يوميًا</option>
                            <option value="أسبوعيًا">أسبوعيًا</option>
                            <option value="شهريًا">شهريًا</option>
                        </select>
                    </div>
                     <div className="lg:col-span-3">
                        <label htmlFor="unionAchievements" className="block text-sm font-medium text-slate-700 mb-1">الإنجازات داخل الاتحاد</label>
                        <textarea id="unionAchievements" value={formData.unionAchievements || ''} onChange={handleChange} rows={3} className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm"></textarea>
                    </div>
                 </div>
            </details>

            {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
          </main>

          <footer className="bg-slate-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200">
            <button type="button" onClick={onClose} className="bg-slate-200 text-slate-700 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 transition-colors">إلغاء</button>
            <button type="submit" className="bg-amber-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-amber-600 transition-colors shadow-sm hover:shadow-md">حفظ التغييرات</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default EditAccountModal;