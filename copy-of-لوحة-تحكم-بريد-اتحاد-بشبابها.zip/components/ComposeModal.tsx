import React, { useState, useEffect } from 'react';
import type { EmailAccount } from '../types';
import CloseIcon from './icons/CloseIcon';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';
import Avatar from './Avatar';

interface ComposeModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: EmailAccount[];
  initialRecipient?: string;
  senderAccount: EmailAccount;
  onSendMessage: (message: { from: string; to: string[]; subject: string; body: string; }) => void;
}

const ComposeModal: React.FC<ComposeModalProps> = ({ isOpen, onClose, accounts, initialRecipient, senderAccount, onSendMessage }) => {
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  
  useEffect(() => {
    if (isOpen) {
      const signatureText = senderAccount.signature 
        ? `\n\n-- \n${senderAccount.signature}` 
        : `\n\n-- \n${senderAccount.fullName}\n${senderAccount.unionPosition}`;
      setTo(initialRecipient || '');
      setSubject('');
      setBody(signatureText);
    } else {
      // Reset state when closed
      setTo('');
      setSubject('');
      setBody('');
    }
  }, [initialRecipient, isOpen, senderAccount]);

  const handleSend = () => {
    const signatureText = senderAccount.signature 
        ? `\n\n-- \n${senderAccount.signature}` 
        : `\n\n-- \n${senderAccount.fullName}\n${senderAccount.unionPosition}`;
    const trimmedBody = body.trim();
    const trimmedSignature = signatureText.trim();

    if (!to || !subject || trimmedBody === '' || trimmedBody === trimmedSignature) {
        alert("الرجاء إدخال المستلم والموضوع ومحتوى الرسالة.");
        return;
    }
    
    const recipients = to.split(',').map(email => email.trim()).filter(email => email);

    if (recipients.length === 0) {
        alert("الرجاء إدخال بريد إلكتروني واحد على الأقل للمستلم.");
        return;
    }

    onSendMessage({
        from: senderAccount.email,
        to: recipients,
        subject,
        body,
    });
    
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div 
        className="fixed inset-0 bg-slate-900 bg-opacity-60 dark:bg-opacity-80 z-50 flex justify-center items-center p-4 backdrop-blur-sm" 
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-labelledby="compose-modal-title"
    >
      <div 
        className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-4xl h-[90vh] max-h-[700px] flex flex-col transform transition-all" 
        onClick={(e) => e.stopPropagation()}
      >
        <header className="p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
          <div className="flex justify-between items-center">
            <h2 id="compose-modal-title" className="text-lg font-bold text-slate-800 dark:text-slate-100">
              رسالة جديدة
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors" aria-label="إغلاق">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>

        <div className="flex-1 flex flex-row overflow-hidden">
            <main className="w-2/3 p-5 flex flex-col text-slate-800 dark:text-slate-200">
                 <div className="mb-4 flex items-center border-b border-slate-300 dark:border-slate-600 focus-within:border-amber-500">
                    <label htmlFor="to" className="text-sm font-medium text-slate-500 dark:text-slate-400 pl-3">إلى:</label>
                    <input
                        type="text"
                        id="to"
                        value={to}
                        onChange={e => setTo(e.target.value)}
                        placeholder="أدخل البريد الإلكتروني للمستلم أو المستلمين مفصولين بفاصلة"
                        className="w-full px-3 py-2 text-md border-0 focus:outline-none focus:ring-0 bg-transparent"
                    />
                 </div>
                 <div className="mb-4">
                    <label htmlFor="subject" className="sr-only">الموضوع</label>
                    <input
                        type="text"
                        id="subject"
                        value={subject}
                        onChange={e => setSubject(e.target.value)}
                        placeholder="الموضوع"
                        className="w-full px-3 py-2 text-lg font-semibold border-b border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-0 focus:border-amber-500 bg-transparent"
                    />
                 </div>
                 <div className="flex-1 mt-2">
                    <label htmlFor="body" className="sr-only">نص الرسالة</label>
                    <textarea
                        id="body"
                        value={body}
                        onChange={e => setBody(e.target.value)}
                        placeholder="اكتب رسالتك هنا..."
                        className="w-full h-full p-3 resize-none border-0 focus:outline-none focus:ring-0 bg-transparent"
                    ></textarea>
                 </div>
            </main>
            <aside className="w-1/3 border-l border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 flex flex-col">
                <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                    <h3 className="font-semibold text-slate-700 dark:text-slate-200">جهات الاتصال ({accounts.length})</h3>
                </div>
                <div className="overflow-y-auto flex-1">
                    {accounts.length > 0 ? (
                        <ul>
                            {accounts.map(account => (
                                <li key={account.id} className="p-3 flex items-center gap-3 border-b border-slate-100 dark:border-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer transition-colors" onClick={() => setTo(prev => prev ? `${prev}, ${account.email}` : account.email)}>
                                    <Avatar account={account} size="w-10 h-10" />
                                    <div>
                                        <p className="font-semibold text-sm text-slate-800 dark:text-slate-200">{account.fullName}</p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">{account.email}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <div className="p-4 text-center text-sm text-slate-500 dark:text-slate-400">
                            لا توجد حسابات مسجلة لعرضها.
                        </div>
                    )}
                </div>
            </aside>
        </div>

        <footer className="bg-slate-50 dark:bg-slate-800 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={onClose}
            className="bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
          >
            إلغاء
          </button>
          <button
            onClick={handleSend}
            className="bg-amber-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-amber-600 transition-colors flex items-center gap-2 shadow-sm hover:shadow-md"
          >
            <PaperAirplaneIcon className="w-5 h-5"/>
            <span>إرسال</span>
          </button>
        </footer>
      </div>
    </div>
  );
};

export default ComposeModal;