import React, { useState, useEffect, useRef } from 'react';
import type { EmailAccount } from '../types';
import type { SidebarItem } from './MailboxPage';
import CloseIcon from './icons/CloseIcon';
import Cog6ToothIcon from './icons/Cog6ToothIcon';
import Bars3Icon from './icons/Bars3Icon';
import SunIcon from './icons/SunIcon';
import MoonIcon from './icons/MoonIcon';
import ComputerDesktopIcon from './icons/ComputerDesktopIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';

type MailboxView = 'inbox' | 'sent' | 'trash' | 'spam' | 'alerts';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: EmailAccount;
  onUpdateAccount: (account: EmailAccount) => void;
  sidebarConfig: SidebarItem[];
  onUpdateSidebarConfig: (config: SidebarItem[]) => void;
  theme: string;
  onSetTheme: (theme: string) => void;
}

type SettingsTab = 'profile' | 'signature' | 'sidebar' | 'appearance' | 'security';

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, account, onUpdateAccount, sidebarConfig, onUpdateSidebarConfig, theme, onSetTheme }) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [formData, setFormData] = useState<Partial<EmailAccount>>({});
  const [localTheme, setLocalTheme] = useState(theme);
  
  const [editedSidebarItems, setEditedSidebarItems] = useState<SidebarItem[]>([]);
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);

  // State for staged password change
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [stagedPassword, setStagedPassword] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    if (isOpen) {
      setFormData(account);
      setEditedSidebarItems([...sidebarConfig]);
      setLocalTheme(theme);
      setActiveTab('profile'); 
      // Reset password form
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setStagedPassword(null);
      setPasswordError('');
    }
  }, [isOpen, account, sidebarConfig, theme]);

  const handleSave = () => {
    let updatedAccountData: EmailAccount = {
      ...account,
      ...formData,
    };
    if (stagedPassword) {
      updatedAccountData.password = stagedPassword;
    }
    
    onUpdateAccount(updatedAccountData);
    onUpdateSidebarConfig(editedSidebarItems);
    onSetTheme(localTheme);
    onClose();
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [id]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [id]: value }));
    }
  };
  
  const handleToggleVisibility = (id: MailboxView) => {
      setEditedSidebarItems(prev => 
          prev.map(item => item.id === id ? { ...item, visible: !item.visible } : item)
      );
  };
  const handleDragStart = (e: React.DragEvent<HTMLLIElement>, index: number) => {
      dragItem.current = index;
  };
  const handleDragEnter = (e: React.DragEvent<HTMLLIElement>, index: number) => {
      dragOverItem.current = index;
  };
  const handleDrop = () => {
      if (dragItem.current === null || dragOverItem.current === null || dragItem.current === dragOverItem.current) return;
      const newItems = [...editedSidebarItems];
      const dragItemContent = newItems.splice(dragItem.current, 1)[0];
      newItems.splice(dragOverItem.current, 0, dragItemContent);
      dragItem.current = null;
      dragOverItem.current = null;
      setEditedSidebarItems(newItems);
  };

  const handleStagePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setStagedPassword(null);

    if (!currentPassword || !newPassword || !confirmPassword) {
      setPasswordError('الرجاء ملء جميع الحقول.');
      return;
    }
    if (account.password !== currentPassword) {
      setPasswordError('كلمة المرور الحالية غير صحيحة.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError('يجب أن لا تقل كلمة المرور الجديدة عن 8 أحرف.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('كلمتا المرور الجديدتان غير متطابقتين.');
      return;
    }
     if (newPassword === currentPassword) {
      setPasswordError('كلمة المرور الجديدة يجب أن تكون مختلفة عن الحالية.');
      return;
    }

    setStagedPassword(newPassword);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-3xl transform transition-all" onClick={(e) => e.stopPropagation()}>
        <header className="p-5 border-b border-slate-200 dark:border-slate-700">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-3">
              <Cog6ToothIcon className="w-6 h-6 text-amber-600" />
              إعدادات الحساب
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>
          
        <main className="p-6">
          <div className="border-b border-slate-200 dark:border-slate-600 mb-6">
            <nav className="-mb-px flex space-x-4 space-x-reverse" aria-label="Tabs">
              <button
                onClick={() => setActiveTab('profile')}
                className={`${
                  activeTab === 'profile'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-500'
                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-all`}
              >
                الملف الشخصي
              </button>
              <button
                onClick={() => setActiveTab('signature')}
                className={`${
                  activeTab === 'signature'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-500'
                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-all`}
              >
                التوقيع
              </button>
              <button
                onClick={() => setActiveTab('sidebar')}
                className={`${
                  activeTab === 'sidebar'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-500'
                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-all`}
              >
                القائمة
              </button>
               <button
                onClick={() => setActiveTab('appearance')}
                className={`${
                  activeTab === 'appearance'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-500'
                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-all`}
              >
                المظهر
              </button>
              <button
                onClick={() => setActiveTab('security')}
                className={`${
                  activeTab === 'security'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:border-slate-300 dark:hover:border-slate-500'
                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-all`}
              >
                الأمان
              </button>
            </nav>
          </div>

          <div className="max-h-[50vh] overflow-y-auto pr-2 space-y-6">
            {activeTab === 'profile' && (
                <div className="space-y-6">
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                        املأ هذه البيانات للمساعدة في بناء شبكة قوية داخل الاتحاد وتسهيل التواصل.
                    </p>
                    {/* Personal Info */}
                    <fieldset>
                        <legend className="text-md font-semibold text-slate-800 dark:text-slate-200 mb-2">البيانات الشخصية</legend>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                            <div>
                                <label htmlFor="gender" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">النوع</label>
                                <select id="gender" value={formData.gender || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg">
                                    <option value="">اختر...</option>
                                    <option value="ذكر">ذكر</option>
                                    <option value="أنثى">أنثى</option>
                                </select>
                            </div>
                             <div>
                                <label htmlFor="maritalStatus" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الحالة الاجتماعية</label>
                                <input type="text" id="maritalStatus" value={formData.maritalStatus || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg" />
                            </div>
                             <div className="md:col-span-2">
                                <label htmlFor="address" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">العنوان</label>
                                <input type="text" id="address" value={formData.address || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg" />
                            </div>
                         </div>
                    </fieldset>
                     {/* Educational Info */}
                    <fieldset>
                        <legend className="text-md font-semibold text-slate-800 dark:text-slate-200 mb-2">الحالة التعليمية</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                           <div>
                                <label htmlFor="qualification" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">المؤهل الدراسي</label>
                                <input type="text" id="qualification" value={formData.qualification || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg" />
                            </div>
                            <div>
                                <label htmlFor="studyStatus" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الحالة الدراسية</label>
                                 <select id="studyStatus" value={formData.studyStatus || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg">
                                    <option value="">اختر...</option>
                                    <option value="طالب">طالب</option>
                                    <option value="خريج">خريج</option>
                                    <option value="دراسات عليا">دراسات عليا</option>
                                </select>
                            </div>
                        </div>
                    </fieldset>
                    {/* Professional Info */}
                    <fieldset>
                        <legend className="text-md font-semibold text-slate-800 dark:text-slate-200 mb-2">الحالة الوظيفية</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-lg">
                            <div>
                                <label htmlFor="currentJob" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الوظيفة الحالية</label>
                                <input type="text" id="currentJob" value={formData.currentJob || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg" />
                            </div>
                            <div>
                                <label htmlFor="employer" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">جهة العمل</label>
                                <input type="text" id="employer" value={formData.employer || ''} onChange={handleFormChange} className="w-full p-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg" />
                            </div>
                             <div className="md:col-span-2 flex items-center gap-3">
                                <input type="checkbox" id="availableForVolunteering" checked={formData.availableForVolunteering || false} onChange={handleFormChange} className="w-4 h-4 text-amber-600 border-slate-300 rounded focus:ring-amber-500"/>
                                <label htmlFor="availableForVolunteering" className="text-sm font-medium text-slate-700 dark:text-slate-300">متاح للعمل التطوعي</label>
                            </div>
                        </div>
                    </fieldset>
                </div>
            )}
            {activeTab === 'signature' && (
              <div>
                <label htmlFor="signature" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">
                  توقيعك
                </label>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">
                  سيتم إلحاق هذا التوقيع تلقائياً في نهاية كل رسالة ترسلها.
                </p>
                <textarea
                  id="signature"
                  rows={6}
                  value={formData.signature || ''}
                  onChange={handleFormChange}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 font-sans"
                  placeholder={`مثال:\n${account.fullName}\n${account.unionPosition}\n${account.mobileNumber}`}
                />
              </div>
            )}

            {activeTab === 'sidebar' && (
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">
                  قم بسحب وإفلات العناصر لترتيب القائمة، أو قم بتبديل المفتاح لإظهار أو إخفاء أي عنصر.
                </p>
                <ul onDrop={handleDrop} onDragOver={(e) => e.preventDefault()}>
                  {editedSidebarItems.map((item, index) => (
                      <li 
                          key={item.id}
                          draggable
                          onDragStart={(e) => handleDragStart(e, index)}
                          onDragEnter={(e) => handleDragEnter(e, index)}
                          className="flex items-center gap-2 pl-4 pr-2 py-2 text-sm font-semibold text-slate-700 dark:text-slate-200 rounded-lg bg-slate-100 dark:bg-slate-700 mb-2 border border-slate-200 dark:border-slate-600 select-none"
                      >
                          <div className="cursor-grab p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                              <Bars3Icon className="w-5 h-5" />
                          </div>
                          <span className="flex-grow text-right">{item.label}</span>
                          <label htmlFor={`toggle-${item.id}`} className="relative inline-flex items-center cursor-pointer">
                              <input 
                                  type="checkbox" 
                                  checked={item.visible} 
                                  id={`toggle-${item.id}`} 
                                  className="sr-only peer"
                                  onChange={() => handleToggleVisibility(item.id as MailboxView)}
                              />
                              <div className="w-11 h-6 bg-slate-200 rounded-full peer peer-focus:ring-2 peer-focus:ring-amber-300 dark:peer-focus:ring-amber-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                          </label>
                      </li>
                  ))}
              </ul>
              </div>
            )}
             {activeTab === 'appearance' && (
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  اختر المظهر المفضل لديك لواجهة البريد الإلكتروني.
                </p>
                <div className="space-y-3">
                  <button type="button" onClick={() => setLocalTheme('light')} className={`w-full p-4 rounded-lg border-2 transition-colors flex items-center gap-4 text-left ${localTheme === 'light' ? 'border-amber-500 bg-amber-50' : 'border-slate-200 hover:border-slate-300 bg-white'}`}>
                    <SunIcon className="w-6 h-6 text-amber-500 flex-shrink-0" />
                    <div>
                      <span className="font-semibold text-slate-700">فاتح</span>
                      <p className="text-xs text-slate-500">خلفية فاتحة مع نصوص داكنة.</p>
                    </div>
                  </button>
                  <button type="button" onClick={() => setLocalTheme('dark')} className={`w-full p-4 rounded-lg border-2 transition-colors flex items-center gap-4 text-left ${localTheme === 'dark' ? 'border-amber-500 bg-slate-700' : 'border-slate-600 hover:border-slate-500 bg-slate-800'}`}>
                    <MoonIcon className="w-6 h-6 text-indigo-400 flex-shrink-0" />
                    <div>
                      <span className="font-semibold text-white">داكن</span>
                       <p className="text-xs text-slate-400">خلفية داكنة مع نصوص فاتحة.</p>
                    </div>
                  </button>
                  <button type="button" onClick={() => setLocalTheme('system')} className={`w-full p-4 rounded-lg border-2 transition-colors flex items-center gap-4 text-left ${localTheme === 'system' ? 'border-amber-500 bg-slate-50 dark:bg-slate-700' : 'border-slate-200 dark:border-slate-600 hover:border-slate-300 dark:hover:border-slate-500 bg-white dark:bg-slate-800'}`}>
                    <ComputerDesktopIcon className="w-6 h-6 text-slate-500 dark:text-slate-400 flex-shrink-0" />
                     <div>
                        <span className="font-semibold text-slate-700 dark:text-slate-200">افتراضي (النظام)</span>
                        <p className="text-xs text-slate-500 dark:text-slate-400">مزامنة تلقائية مع إعدادات نظامك.</p>
                    </div>
                  </button>
                </div>
              </div>
            )}
             {activeTab === 'security' && (
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  لتغيير كلمة المرور، أدخل كلمة المرور الحالية ثم الجديدة. سيتم تطبيق التغيير بعد الضغط على "حفظ التغييرات".
                </p>
                <form onSubmit={handleStagePasswordChange} className="space-y-4">
                  <div>
                    <label htmlFor="currentPassword" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">
                      كلمة المرور الحالية
                    </label>
                    <input
                      type="password"
                      id="currentPassword"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      required
                      disabled={!!stagedPassword}
                    />
                  </div>
                  <div>
                    <label htmlFor="newPassword" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">
                      كلمة المرور الجديدة
                    </label>
                    <input
                      type="password"
                      id="newPassword"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      required
                      disabled={!!stagedPassword}
                    />
                  </div>
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1">
                      تأكيد كلمة المرور الجديدة
                    </label>
                    <input
                      type="password"
                      id="confirmPassword"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                      required
                      disabled={!!stagedPassword}
                    />
                  </div>
                  
                  {passwordError && <p className="text-sm text-red-600">{passwordError}</p>}
                  
                  {stagedPassword && (
                    <div className="bg-green-50 dark:bg-green-500/10 border-r-4 border-green-500 p-4 text-green-800 dark:text-green-300 rounded-lg shadow-sm" role="alert">
                      <p className="font-bold flex items-center gap-2">
                        <ShieldCheckIcon className="w-5 h-5"/>
                        تم تجهيز كلمة المرور الجديدة بنجاح.
                      </p>
                      <p className="text-sm mt-1">اضغط على "حفظ التغييرات" في الأسفل لتأكيد التغيير.</p>
                    </div>
                  )}

                  <div className="pt-2">
                      <button type="submit" className="bg-slate-600 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-slate-700 transition-colors shadow-sm disabled:opacity-50" disabled={!!stagedPassword}>
                          {stagedPassword ? 'تم التجهيز' : 'تجهيز كلمة المرور'}
                      </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </main>

        <footer className="bg-slate-50 dark:bg-slate-700/50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200 dark:border-slate-700">
          <button
            onClick={onClose}
            className="bg-slate-200 text-slate-700 dark:bg-slate-600 dark:text-slate-200 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors"
          >
            إلغاء
          </button>
          <button
            onClick={handleSave}
            className="bg-amber-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-amber-600 transition-colors shadow-sm hover:shadow-md"
          >
            حفظ التغييرات
          </button>
        </footer>
      </div>
    </div>
  );
};

export default SettingsModal;