import React from 'react';
import BeShababhaLogo from './icons/YouthUnionLogo';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-slate-900">
      <div className="text-center">
        <BeShababhaLogo className="w-auto h-28 mx-auto animate-pulse" />
        <p className="mt-4 text-lg font-semibold text-slate-600 dark:text-slate-300">
          جاري تحميل البيانات...
        </p>
      </div>
    </div>
  );
};

export default LoadingSpinner;
