import React, { useState } from 'react';
import type { Event, EmailAccount } from '../types';
import CalendarDaysIcon from './icons/CalendarDaysIcon';
import UsersIcon from './icons/UsersIcon';
import ArrowDownTrayIcon from './icons/ArrowDownTrayIcon';
import DocumentArrowDownIcon from './icons/DocumentArrowDownIcon';

interface EventManagementViewProps {
  events: Event[];
  accounts: EmailAccount[];
}

const EventManagementView: React.FC<EventManagementViewProps> = ({ events, accounts }) => {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  const attendees = selectedEvent
    ? selectedEvent.attendees
        .map(attendeeId => accounts.find(acc => acc.id === attendeeId))
        .filter((acc): acc is EmailAccount => !!acc)
    : [];

  const handleExportCSV = () => {
    if (!selectedEvent || attendees.length === 0) {
      alert('لا يوجد مشاركين لتصديرهم.');
      return;
    }
    
    const headers = ["الاسم الكامل", "الرقم القومي", "رقم الموبايل"];
    const csvRows = [
      headers.join(','),
      ...attendees.map(acc => 
        [`"${acc.fullName}"`, `"${acc.nationalId}"`, `"${acc.mobileNumber}"`].join(',')
      )
    ];

    const csvString = csvRows.join('\n');
    const blob = new Blob([`\uFEFF${csvString}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `attendees_${selectedEvent.name.replace(/\s/g, '_')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    if (!selectedEvent || attendees.length === 0) {
      alert('لا يوجد مشاركين لطباعتهم.');
      return;
    }
    window.print();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Event List */}
      <div className="lg:col-span-1">
        <div className="bg-white p-5 rounded-2xl shadow-xl">
          <h2 className="text-xl font-bold text-slate-800 mb-4 border-b pb-3">قائمة الفعاليات</h2>
          {events.length === 0 ? (
            <div className="text-center py-10">
              <CalendarDaysIcon className="w-12 h-12 mx-auto text-slate-300" />
              <p className="mt-2 text-slate-500">لم يتم إنشاء أي فعاليات بعد.</p>
            </div>
          ) : (
            <ul className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
              {events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(event => (
                <li key={event.id}>
                  <button 
                    onClick={() => setSelectedEvent(event)}
                    className={`w-full p-4 text-right rounded-lg border-2 transition-all duration-200 ${selectedEvent?.id === event.id ? 'bg-amber-50 border-amber-500 shadow-md' : 'bg-slate-50 border-transparent hover:border-amber-300 hover:bg-amber-50'}`}
                  >
                    <p className="font-bold text-slate-800">{event.name}</p>
                    <p className="text-sm text-slate-500 mt-1">
                      {new Date(event.date).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                    <div className="flex items-center gap-2 text-sm text-teal-600 font-semibold mt-2">
                      <UsersIcon className="w-4 h-4" />
                      <span>{event.attendees.length} مشارك مؤكد</span>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Attendee Details */}
      <div className="lg:col-span-2">
        {!selectedEvent ? (
          <div className="flex items-center justify-center h-full bg-white p-10 rounded-2xl shadow-xl text-center">
            <div>
              <UsersIcon className="w-20 h-20 mx-auto text-slate-300" />
              <h3 className="text-xl font-semibold text-slate-700 mt-4">اختر فاعلية لعرض المشاركين</h3>
              <p className="text-slate-500 mt-2">سيتم عرض تفاصيل الحضور هنا.</p>
            </div>
          </div>
        ) : (
          <div id="printable-area" className="bg-white p-6 rounded-2xl shadow-xl">
            <header className="mb-6">
              <h2 className="text-2xl font-extrabold text-slate-900">{selectedEvent.name}</h2>
              <p className="text-slate-500">قائمة الحضور المؤكد</p>
            </header>
            
            <div className="flex items-center justify-end gap-3 flex-wrap mb-4 print:hidden">
              <button onClick={handleExportCSV} className="flex items-center gap-2 bg-green-100 text-green-800 font-semibold px-4 py-2 rounded-lg hover:bg-green-200 text-sm">
                <ArrowDownTrayIcon className="w-5 h-5"/> <span>تصدير CSV</span>
              </button>
              <button onClick={handlePrint} className="flex items-center gap-2 bg-red-100 text-red-800 font-semibold px-4 py-2 rounded-lg hover:bg-red-200 text-sm">
                <DocumentArrowDownIcon className="w-5 h-5"/> <span>طباعة / PDF</span>
              </button>
            </div>

            {attendees.length === 0 ? (
              <div className="text-center py-20 border-t">
                 <UsersIcon className="w-16 h-16 mx-auto text-slate-300" />
                <h3 className="text-xl font-semibold text-slate-700 mt-4">لا يوجد حضور مؤكد بعد</h3>
                <p className="text-slate-500 mt-2">لم يقم أي عضو بتأكيد الحضور في هذه الفاعلية حتى الآن.</p>
              </div>
            ) : (
                <div className="overflow-x-auto border-t">
                  <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">الاسم الكامل</th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">الرقم القومي</th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">رقم الموبايل</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-slate-200">
                      {attendees.map(attendee => (
                        <tr key={attendee.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{attendee.fullName}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono tracking-wider">{attendee.nationalId}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 font-mono tracking-wider">{attendee.mobileNumber}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default EventManagementView;
