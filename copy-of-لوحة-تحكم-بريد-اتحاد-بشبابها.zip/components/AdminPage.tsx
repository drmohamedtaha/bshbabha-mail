import React, { useState } from 'react';
import type { EmailAccount, Event, CandidateMatch } from '../types';
import AccountManagementView from './AccountManagementView';
import ComposeModal from './ComposeModal';
import CreateEmailForm from './CreateEmailForm';
import BulkCreateModal from './BulkCreateModal';
import UrgentAlertModal from './UrgentAlertModal';
import AddEventModal from './AddEventModal';
import LogoutIcon from './icons/LogoutIcon';
import BeShababhaLogo from './icons/YouthUnionLogo.tsx';
import UsersIcon from './icons/UsersIcon';
import UserIcon from './icons/UserIcon';
import UserGroupIcon from './icons/UserGroupIcon';
import MegaphoneIcon from './icons/MegaphoneIcon';
import ArrowDownTrayIcon from './icons/ArrowDownTrayIcon';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';
import CalendarDaysIcon from './icons/CalendarDaysIcon';
import EventManagementView from './EventManagementView';
import LightBulbIcon from './icons/LightBulbIcon.tsx';
import OpportunityFinderView from './OpportunityFinderView.tsx';
import { findBestCandidates } from '../services/geminiService';

interface AdminPageProps {
  onLogout: () => void;
  allAccounts: EmailAccount[];
  events: Event[];
  onUpdateAccount: (account: EmailAccount) => void;
  onDeleteAccount: (id: string) => void;
  onSendAlert: (alertData: { subject: string; body: string }) => void;
  onSendMessage: (message: { from: string; to: string[]; subject: string; body: string; }) => void;
  onAccountCreate: (account: EmailAccount) => Promise<void>;
  onBulkCreate: (accounts: EmailAccount[]) => void;
  onCreateEvent: (eventData: { name: string; date: string; location: string; description: string; }) => void;
  syncStatus: string; // Kept for prop compatibility, but not used.
}

const AdminPage: React.FC<AdminPageProps> = (props) => {
  const { 
    onLogout, allAccounts, events, onUpdateAccount, onDeleteAccount, onSendAlert, 
    onSendMessage, onAccountCreate, onBulkCreate, onCreateEvent
  } = props;
  
  const [view, setView] = useState<'accounts' | 'events' | 'createSingle' | 'finder'>('accounts');
  const [isComposeOpen, setComposeOpen] = useState(false);
  const [isBulkModalOpen, setBulkModalOpen] = useState(false);
  const [isAlertModalOpen, setAlertModalOpen] = useState(false);
  const [isEventModalOpen, setEventModalOpen] = useState(false);
  const [initialRecipient, setInitialRecipient] = useState<string | undefined>(undefined);
  const [candidates, setCandidates] = useState<CandidateMatch[]>([]);
  const [isFinding, setIsFinding] = useState(false);
  const [finderError, setFinderError] = useState('');

  const adminSenderAccount: EmailAccount = {
    id: 'admin',
    fullName: 'إدارة الاتحاد',
    username: 'admin',
    email: 'admin@youthunion.org',
    createdAt: new Date().toISOString(),
    nationalId: '',
    dateOfBirth: '',
    governorate: '',
    unionPosition: 'مسؤول',
    mobileNumber: '',
    whatsappNumber: '',
    personalEmail: '',
    signature: 'مع تحياتنا،\nإدارة اتحاد بشبابها',
    participations: [],
  };

  const openCompose = (recipient?: string) => {
    if (recipient) {
      setInitialRecipient(recipient);
    } else {
      const allEmails = allAccounts.map(acc => acc.email).join(', ');
      setInitialRecipient(allEmails);
    }
    setComposeOpen(true);
  };
    
  const closeCompose = () => {
    setInitialRecipient(undefined);
    setComposeOpen(false);
  };
  
  const handleExportCSV = () => {
    if (allAccounts.length === 0) {
      alert('لا توجد بيانات لتصديرها.');
      return;
    }

    const headers = [
      "الاسم الكامل", "البريد الإلكتروني", "الصفة بالاتحاد", "المحافظة",
      "تاريخ الميلاد", "الرقم القومي", "رقم الموبايل", "رقم الواتس اب", "الإيميل الشخصي", "تاريخ الإنشاء"
    ];

    const csvRows = [
      headers.join(','),
      ...allAccounts.map(acc => [
        `"${acc.fullName}"`, `"${acc.email}"`, `"${acc.unionPosition}"`,
        `"${acc.governorate}"`, `"${acc.dateOfBirth}"`, `"${acc.nationalId}"`, `"${acc.mobileNumber}"`,
        `"${acc.whatsappNumber}"`, `"${acc.personalEmail}"`, `"${new Date(acc.createdAt).toLocaleDateString('ar-EG')}"`,
      ].join(','))
    ];

    const csvString = csvRows.join('\n');
    const blob = new Blob([`\uFEFF${csvString}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'youthunion_accounts.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleFindCandidates = async (description: string) => {
    setIsFinding(true);
    setFinderError('');
    setCandidates([]);
    try {
        const results = await findBestCandidates(description, allAccounts);
        setCandidates(results);
    } catch (error: any) {
        setFinderError(error.message || 'حدث خطأ غير متوقع أثناء البحث.');
    } finally {
        setIsFinding(false);
    }
  };

  return (
    <>
      <div className="flex min-h-screen flex-col bg-slate-100">
        <header className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-30">
            <div className="flex items-center gap-4">
                <BeShababhaLogo className="w-auto h-12" />
                <h1 className="text-2xl font-bold text-slate-800 hidden sm:block">لوحة تحكم المسؤول</h1>
            </div>
            <button 
                onClick={onLogout} 
                className="flex items-center gap-2 bg-slate-100 text-slate-700 hover:bg-red-50 hover:text-red-600 font-semibold px-4 py-2 rounded-lg transition-colors duration-200"
            >
                <LogoutIcon className="w-5 h-5" />
                <span>تسجيل الخروج</span>
            </button>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <div className="bg-white rounded-xl shadow-lg p-4 mb-6">
            <div className="flex flex-wrap items-center gap-2">
              <button onClick={() => setView('accounts')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm sm:text-base font-bold transition-all duration-300 ${view === 'accounts' ? 'bg-amber-500 text-white shadow-md' : 'bg-transparent text-slate-600 hover:bg-amber-50'}`}>
                <UsersIcon className="w-5 h-5"/> إدارة الحسابات ({allAccounts.length})
              </button>
               <button onClick={() => setView('events')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm sm:text-base font-bold transition-all duration-300 ${view === 'events' ? 'bg-amber-500 text-white shadow-md' : 'bg-transparent text-slate-600 hover:bg-amber-50'}`}>
                <CalendarDaysIcon className="w-5 h-5"/> إدارة الفعاليات ({events.length})
              </button>
              <button onClick={() => setView('finder')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm sm:text-base font-bold transition-all duration-300 ${view === 'finder' ? 'bg-amber-500 text-white shadow-md' : 'bg-transparent text-slate-600 hover:bg-amber-50'}`}>
                <LightBulbIcon className="w-5 h-5"/> البحث الذكي
              </button>
              <button onClick={() => setView('createSingle')} className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm sm:text-base font-bold transition-all duration-300 ${view === 'createSingle' ? 'bg-amber-500 text-white shadow-md' : 'bg-transparent text-slate-600 hover:bg-amber-50'}`}>
                <UserIcon className="w-5 h-5"/> إنشاء حساب فردي
              </button>
            </div>
          </div>
          
          {view === 'accounts' && (
            <>
              <div className="flex items-center justify-end gap-3 flex-wrap mb-6">
                  <button onClick={handleExportCSV} className="flex items-center gap-2 bg-white text-slate-700 font-semibold px-4 py-2 rounded-lg hover:bg-slate-50 border border-slate-300 shadow-sm">
                      <ArrowDownTrayIcon className="w-5 h-5"/> <span>تصدير CSV</span>
                  </button>
                  <button onClick={() => setAlertModalOpen(true)} className="flex items-center gap-2 bg-yellow-400 text-yellow-900 font-semibold px-4 py-2 rounded-lg hover:bg-yellow-500 shadow-sm">
                      <MegaphoneIcon className="w-5 h-5"/> <span>تنبيه عاجل</span>
                  </button>
                  <button onClick={() => setEventModalOpen(true)} className="flex items-center gap-2 bg-teal-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-teal-600 shadow-sm">
                      <CalendarDaysIcon className="w-5 h-5"/> <span>إضافة فاعلية</span>
                  </button>
                   <button onClick={() => setBulkModalOpen(true)} className="flex items-center gap-2 bg-indigo-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-indigo-600 shadow-sm">
                      <UserGroupIcon className="w-5 h-5"/> <span>إنشاء جماعي</span>
                  </button>
                  <button onClick={() => openCompose()} className="flex items-center gap-2 bg-green-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-green-600 shadow-sm">
                      <PaperAirplaneIcon className="w-5 h-5"/> <span>رسالة جماعية</span>
                  </button>
              </div>
              <AccountManagementView 
                accounts={allAccounts} 
                onUpdateAccount={onUpdateAccount}
                onDeleteAccount={onDeleteAccount}
                onComposeMessage={openCompose}
              />
            </>
          )}

          {view === 'events' && (
             <EventManagementView events={events} accounts={allAccounts} />
          )}

          {view === 'finder' && (
            <OpportunityFinderView
              onFindCandidates={handleFindCandidates}
              isLoading={isFinding}
              results={candidates}
              accounts={allAccounts}
              error={finderError}
              onComposeMessage={openCompose}
              onUpdateAccount={onUpdateAccount}
            />
          )}

          {view === 'createSingle' && (
            <div className="mt-6 max-w-4xl mx-auto">
              <CreateEmailForm 
                onAccountCreate={async (newAccount) => {
                  await onAccountCreate(newAccount);
                  setView('accounts'); 
                }} 
                domain="youthunion.org"
                accounts={allAccounts}
              />
            </div>
          )}
        </main>
      </div>

      <ComposeModal 
        isOpen={isComposeOpen} 
        onClose={closeCompose}
        accounts={allAccounts}
        initialRecipient={initialRecipient}
        senderAccount={adminSenderAccount}
        onSendMessage={onSendMessage}
      />
      <BulkCreateModal
        isOpen={isBulkModalOpen}
        onClose={() => setBulkModalOpen(false)}
        onBulkCreate={onBulkCreate}
        domain="youthunion.org"
      />
      <UrgentAlertModal
        isOpen={isAlertModalOpen}
        onClose={() => setAlertModalOpen(false)}
        onSendAlert={onSendAlert}
      />
      <AddEventModal
        isOpen={isEventModalOpen}
        onClose={() => setEventModalOpen(false)}
        onCreateEvent={onCreateEvent}
      />
    </>
  );
};

export default AdminPage;
