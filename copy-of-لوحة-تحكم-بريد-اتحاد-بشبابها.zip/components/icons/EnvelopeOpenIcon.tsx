import React from 'react';

const EnvelopeOpenIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 9v.906a2.25 2.25 0 01-1.183 1.981l-6.478 3.488M2.25 9v.906c0 .92.59 1.732 1.423 2.063l6.478 3.488M21.75 9a2.25 2.25 0 00-2.25-2.25H4.5A2.25 2.25 0 002.25 9m19.5 0h-19.5M2.25 9L12 4.5 21.75 9" />
  </svg>
);

export default EnvelopeOpenIcon;
