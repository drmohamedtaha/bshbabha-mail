import React from 'react';

const BeShababhaLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 200 140" xmlns="http://www.w3.org/2000/svg" {...props}>
    <style>
      {`.logo-text { 
          font-family: 'Tajawal', sans-serif; 
          font-weight: 700; 
          letter-spacing: 0px;
          paint-order: stroke;
        }`}
    </style>
    
    <defs>
        <linearGradient id="logoTextGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{stopColor: '#fcd34d'}} /> {/* amber-300 */}
            <stop offset="50%" style={{stopColor: '#f59e0b'}} /> {/* amber-500 */}
            <stop offset="100%" style={{stopColor: '#b45309'}} /> {/* amber-700 */}
        </linearGradient>
        <filter id="text-shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="1.5" dy="1.5" stdDeviation="1" floodColor="#000000" floodOpacity="0.3"/>
        </filter>
    </defs>
    
    {/* Icon part */}
    <g transform="translate(0, -10)">
      {/* Central Figure */}
      <circle cx="100" cy="45" r="15" fill="#f59e0b" /> {/* amber-500 */}
      
      {/* Side Figures */}
      <circle cx="70" cy="50" r="13" fill="#fbbf24" /> {/* amber-400 */}
      <circle cx="130" cy="50" r="13" fill="#fbbf24" /> {/* amber-400 */}
      
      {/* Unified Body */}
      <path
        d="M60,100 C 60,70 140,70 140,100 Z"
        fill="#f59e0b" /* amber-500 */
        transform="translate(0, -5)"
      />
    </g>
    
    {/* Text part with shadow and gradient */}
    <text
      x="100"
      y="125"
      className="logo-text"
      fontSize="30"
      textAnchor="middle"
      fill="url(#logoTextGradient)"
      stroke="#451a03" /* amber-950 */
      strokeWidth="1"
      filter="url(#text-shadow)"
    >
      اتحاد بشبابها
    </text>
  </svg>
);

export default BeShababhaLogo;
