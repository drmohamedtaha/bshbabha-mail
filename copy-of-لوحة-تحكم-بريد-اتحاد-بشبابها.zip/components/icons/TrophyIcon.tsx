import React from 'react';

const TrophyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9a9.75 9.75 0 01-4.874-1.972.562.562 0 01.496-.972 8.632 8.632 0 0017.756 0 .562.562 0 01.496.972A9.75 9.75 0 0116.5 18.75z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v-3.75m-3.75 3.75h7.5M9 11.25V9A3 3 0 0112 6v0a3 3 0 013 3v2.25" />
  </svg>
);

export default TrophyIcon;
