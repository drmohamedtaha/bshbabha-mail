import React from 'react';

const ClipboardDocumentListIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 8.25V6a2.25 2.25 0 0 0-2.25-2.25H6A2.25 2.25 0 0 0 3.75 6v8.25A2.25 2.25 0 0 0 6 16.5h2.25m8.25-8.25H18a2.25 2.25 0 0 1 2.25 2.25v8.25A2.25 2.25 0 0 1 18 21.75H8.25A2.25 2.25 0 0 1 6 19.5V16.5m8.25-8.25-5.25 5.25m0 0-5.25 5.25M11.25 13.5l5.25-5.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 13.5H7.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 16.5H7.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 19.5H7.5" />
  </svg>
);

export default ClipboardDocumentListIcon;
