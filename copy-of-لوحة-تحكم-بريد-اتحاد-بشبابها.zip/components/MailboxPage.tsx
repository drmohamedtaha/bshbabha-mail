import React, { useState, useEffect, useRef } from 'react';
import type { EmailAccount, Alert, Message, Event } from '../types';
import InboxIcon from './icons/InboxIcon';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';
import BellIcon from './icons/BellIcon';
import LogoutIcon from './icons/LogoutIcon';
import TrashIcon from './icons/TrashIcon';
import ShieldExclamationIcon from './icons/ShieldExclamationIcon';
import MagnifyingGlassIcon from './icons/MagnifyingGlassIcon';
import ArrowUturnLeftIcon from './icons/ArrowUturnLeftIcon';
import Cog6ToothIcon from './icons/Cog6ToothIcon';
import PencilIcon from './icons/PencilIcon';
import ClipboardDocumentListIcon from './icons/ClipboardDocumentListIcon';
import CalendarDaysIcon from './icons/CalendarDaysIcon';
import ParticipationLogView from './ParticipationLogView';
import EnvelopeOpenIcon from './icons/EnvelopeOpenIcon';

import ComposeModal from './ComposeModal';
import SettingsModal from './SettingsModal';
import BeShababhaLogo from './icons/YouthUnionLogo.tsx';
import Avatar from './Avatar';

interface MailboxPageProps {
  currentUserAccount: EmailAccount;
  onLogout: () => void;
  allAccounts: EmailAccount[];
  alerts: Alert[];
  messages: Message[];
  events: Event[];
  onSendMessage: (message: { from: string; to: string[]; subject: string; body: string; }) => void;
  onUpdateAccount: (account: EmailAccount) => void;
  onRegisterForEvent: (eventId: string, userId: string) => void;
  onDeclineEvent: (eventId: string, userId: string) => void;
  theme: string;
  onSetTheme: (theme: string) => void;
  syncStatus: string;
}

type MailboxView = 'inbox' | 'sent' | 'trash' | 'spam' | 'alerts' | 'participations';
type SelectedItem = (Message & { type: 'message' | 'event' }) | (Alert & { type: 'alert' });

export interface SidebarItem {
  id: MailboxView;
  label: string;
  icon: React.ReactNode;
  visible: boolean;
};

const DEFAULT_SIDEBAR_CONFIG: SidebarItem[] = [
  { id: 'inbox', label: 'البريد الوارد', icon: <InboxIcon className="w-5 h-5"/>, visible: true },
  { id: 'sent', label: 'البريد المرسل', icon: <PaperAirplaneIcon className="w-5 h-5"/>, visible: true },
  { id: 'alerts', label: 'التنبيهات', icon: <BellIcon className="w-5 h-5"/>, visible: true },
  { id: 'participations', label: 'سجل المشاركات', icon: <ClipboardDocumentListIcon className="w-5 h-5"/>, visible: true },
  { id: 'trash', label: 'سلة المحذوفات', icon: <TrashIcon className="w-5 h-5"/>, visible: true },
  { id: 'spam', label: 'البريد المزعج', icon: <ShieldExclamationIcon className="w-5 h-5"/>, visible: true },
];

const MailboxPage: React.FC<MailboxPageProps> = ({ currentUserAccount, onLogout, allAccounts, alerts, messages, events, onSendMessage, onUpdateAccount, onRegisterForEvent, onDeclineEvent, theme, onSetTheme, syncStatus }) => {
    const [view, setView] = useState<MailboxView>('inbox');
    const [isComposeOpen, setComposeOpen] = useState(false);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const [initialRecipient, setInitialRecipient] = useState<string | undefined>(undefined);
    const [selectedItem, setSelectedItem] = useState<SelectedItem | null>(null);
    const [readMessageIds, setReadMessageIds] = useState<Set<string>>(new Set());
    const [sidebarItems, setSidebarItems] = useState<SidebarItem[]>([]);

    useEffect(() => {
      try {
        const savedConfigRaw = localStorage.getItem('mailboxSidebarConfig');
        if (savedConfigRaw) {
          const savedConfig: SidebarItem[] = JSON.parse(savedConfigRaw);
          const mergedConfig = DEFAULT_SIDEBAR_CONFIG.map(defaultItem => {
            const savedItem = savedConfig.find(item => item.id === defaultItem.id);
            return savedItem ? { ...defaultItem, visible: savedItem.visible } : defaultItem;
          });
          const orderedConfig = savedConfig
            .map(savedItem => mergedConfig.find(item => item.id === savedItem.id))
            .filter((item): item is SidebarItem => !!item);
          mergedConfig.forEach(item => {
              if (!orderedConfig.find(o => o.id === item.id)) {
                  orderedConfig.push(item);
              }
          });
          setSidebarItems(orderedConfig);
        } else {
          setSidebarItems(DEFAULT_SIDEBAR_CONFIG);
        }
      } catch (error) {
        console.error("Failed to load or parse sidebar config:", error);
        setSidebarItems(DEFAULT_SIDEBAR_CONFIG);
      }
    }, []);

    const userEmail = currentUserAccount.email;
    const inboxMessages = messages.filter(msg => msg.to.includes(userEmail));
    const sentMessages = messages.filter(msg => msg.from === userEmail);
    const unreadCount = inboxMessages.filter(msg => !msg.read && !readMessageIds.has(msg.id)).length;
    const alertsCount = alerts.length;

    const handleSelectItem = (item: Message | Alert, type: 'message' | 'alert' | 'event') => {
        if ('type' in item && item.type === 'event') {
            setSelectedItem({ ...item, type: 'event' });
        } else {
             setSelectedItem({ ...item, type } as SelectedItem);
        }

        if ('read' in item && !item.read) {
            setReadMessageIds(prev => new Set(prev).add(item.id));
        }
    };

    const openCompose = (recipient?: string) => {
        setInitialRecipient(recipient);
        setComposeOpen(true);
    };
    
    const closeCompose = () => {
        setInitialRecipient(undefined);
        setComposeOpen(false);
    };

    const NavItem: React.FC<{ icon: React.ReactNode; label: string; viewName: MailboxView; count?: number;}> = ({ icon, label, viewName, count }) => (
        <button 
            onClick={() => { setView(viewName); setSelectedItem(null); }} 
            className={`w-full flex items-center gap-4 px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors duration-200 ${view === viewName ? 'bg-amber-100 text-amber-800 dark:bg-amber-500/10 dark:text-amber-400' : 'text-slate-600 hover:bg-slate-200 hover:text-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 dark:hover:text-slate-100'}`}
        >
            {icon}
            <span className="flex-grow text-right">{label}</span>
            {count !== undefined && count > 0 && <span className="bg-amber-500 dark:bg-amber-600 text-white text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full">{count}</span>}
        </button>
    );

    const renderMessageList = () => {
        let items: Array<Message | Alert> = [];
        let itemType: 'message' | 'alert' = 'message';
        let emptyStateTitle = '';
        let emptyStateMessage = '';

        switch(view) {
            case 'inbox':
                items = inboxMessages;
                itemType = 'message';
                emptyStateTitle = 'صندوق البريد الوارد فارغ';
                emptyStateMessage = 'لم تستقبل أي رسائل بعد.';
                break;
            case 'sent':
                items = sentMessages;
                itemType = 'message';
                emptyStateTitle = 'صندوق البريد المرسل فارغ';
                emptyStateMessage = 'لم تقم بإرسال أي رسائل بعد.';
                break;
            case 'alerts':
                items = alerts;
                itemType = 'alert';
                emptyStateTitle = 'لا توجد تنبيهات';
                emptyStateMessage = 'سيتم عرض التنبيهات الرسمية من إدارة الاتحاد هنا.';
                break;
            case 'trash':
                emptyStateTitle = 'سلة المحذوفات فارغة';
                emptyStateMessage = 'الرسائل التي تحذفها ستظهر هنا.';
                break;
            case 'spam':
                emptyStateTitle = 'لا توجد رسائل مزعجة';
                emptyStateMessage = 'الرسائل الموجودة في القائمة السوداء ستظهر هنا.';
                break;
        }

        if (items.length === 0) {
            return (
                <div className="flex items-center justify-center h-full text-center p-4">
                    <div>
                        <InboxIcon className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto"/>
                        <h3 className="text-lg font-medium text-slate-500 dark:text-slate-400 mt-4">{emptyStateTitle}</h3>
                        <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">{emptyStateMessage}</p>
                    </div>
                </div>
            );
        }

        return (
            <ul>
                {items.map(item => {
                    const isMessage = 'from' in item;
                    const isEvent = isMessage && item.type === 'event';
                    const isSelected = selectedItem?.id === item.id;
                    const isUnread = isMessage && !item.read && !readMessageIds.has(item.id);

                    const senderAccount = isMessage ? allAccounts.find(acc => acc.email === item.from) : null;
                    const title = isMessage ? (view === 'inbox' ? (senderAccount?.fullName || item.from) : `إلى: ${item.to.join(', ')}`) : item.subject;
                    const createdAt = (item.createdAt as any)?.toDate ? (item.createdAt as any).toDate() : new Date(item.createdAt);

                    return (
                        <li key={item.id} onClick={() => handleSelectItem(item, isEvent ? 'event' : itemType)}>
                            <button className={`w-full text-right p-4 border-b border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50 flex gap-4 items-start transition-colors duration-150 ${isSelected ? 'bg-amber-50 dark:bg-amber-900/50 border-r-4 border-amber-500' : ''}`}>
                                {isSelected ? (
                                    <div className="w-11 h-11 flex-shrink-0 bg-amber-100 dark:bg-amber-500/10 rounded-full flex items-center justify-center">
                                        <EnvelopeOpenIcon className="w-6 h-6 text-amber-600 dark:text-amber-400"/>
                                    </div>
                                ) : (
                                    <>
                                        {isEvent && <div className="w-11 h-11 flex-shrink-0 bg-teal-100 rounded-full flex items-center justify-center"><CalendarDaysIcon className="w-6 h-6 text-teal-600"/></div>}
                                        {isMessage && !isEvent && <Avatar account={senderAccount || { fullName: item.from }} size="w-11 h-11 flex-shrink-0" />}
                                        {!isMessage && <div className="w-11 h-11 flex-shrink-0 bg-yellow-100 rounded-full flex items-center justify-center"><BellIcon className="w-6 h-6 text-yellow-600"/></div>}
                                    </>
                                )}
                                
                                <div className={`flex-1 min-w-0`}>
                                    <div className="flex justify-between items-baseline">
                                        <p className={`truncate ${isUnread ? 'font-extrabold text-slate-800 dark:text-slate-100' : 'font-bold text-slate-700 dark:text-slate-300'} ${isSelected ? 'text-amber-800 dark:text-amber-400 text-xs' : 'text-sm'}`}>{title}</p>
                                        <p className={`text-xs flex-shrink-0 ${isUnread ? 'text-amber-700 font-bold' : 'text-slate-400 dark:text-slate-500 font-medium'}`}>{createdAt.toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit'})}</p>
                                    </div>
                                    <p className={`truncate mt-0.5 ${isUnread ? 'text-slate-800 dark:text-slate-200' : 'text-slate-600 dark:text-slate-400'} ${isSelected ? 'text-xs' : 'text-sm'}`}>{item.subject}</p>
                                    <p className={`text-slate-500 dark:text-slate-500 font-normal truncate mt-1 ${isSelected ? 'text-xs' : 'text-sm'}`}>{item.body}</p>
                                </div>
                            </button>
                        </li>
                    );
                })}
            </ul>
        );
    };

    const renderPreview = () => {
        if (!selectedItem) {
            return (
                 <div className="flex items-center justify-center h-full text-center p-4 bg-slate-50 dark:bg-slate-900/50">
                    <div>
                        <BeShababhaLogo className="w-auto h-32 mx-auto opacity-20"/>
                        <h3 className="text-xl font-medium text-slate-500 dark:text-slate-400 mt-4">حدد رسالة لعرضها</h3>
                        <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">لا يوجد شيء محدد حالياً.</p>
                    </div>
                </div>
            );
        }
        
        if (selectedItem.type === 'event' && selectedItem.eventId) {
            const event = events.find(e => e.id === selectedItem.eventId);
            if (!event) {
                return (
                    <div className="flex items-center justify-center h-full text-center p-4 bg-slate-50 dark:bg-slate-900/50">
                        <div>
                            <h3 className="text-xl font-medium text-slate-500 dark:text-slate-400">لم يتم العثور على الفاعلية</h3>
                            <p className="text-sm text-slate-400 dark:text-slate-500 mt-1">ربما تم حذف هذه الفاعلية.</p>
                        </div>
                    </div>
                );
            }
            const isRegistered = event.attendees.includes(currentUserAccount.id);
            const hasDeclined = event.declined?.includes(currentUserAccount.id);

            return (
                <div className="flex flex-col h-full">
                    <header className="p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
                        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-3">
                            <CalendarDaysIcon className="w-7 h-7 text-teal-500" />
                            {event.name}
                        </h2>
                        <div className="text-sm text-slate-600 dark:text-slate-400 space-y-1 mt-3 pl-2">
                            <p><strong>التاريخ:</strong> {new Date(event.date).toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                            <p><strong>المكان:</strong> {event.location}</p>
                        </div>
                    </header>
                    <div className="p-6 text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap flex-1 overflow-y-auto">
                        <h3 className="font-bold text-lg mb-2">تفاصيل الفاعلية:</h3>
                        {event.description}
                    </div>
                    <footer className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700">
                        {isRegistered ? (
                            <div className="w-full text-center px-6 py-3 text-base font-bold text-white bg-teal-500 dark:bg-teal-600 rounded-lg shadow-md">
                                تم تأكيد الحضور بنجاح
                            </div>
                        ) : hasDeclined ? (
                             <div className="w-full text-center px-6 py-3 text-base font-bold text-slate-700 bg-slate-200 dark:bg-slate-700 dark:text-slate-300 rounded-lg">
                                تم تسجيل عدم الرغبة في الحضور
                            </div>
                        ) : (
                            <div className="flex items-center justify-center gap-4">
                                <button
                                    onClick={() => onDeclineEvent(event.id, currentUserAccount.id)}
                                    className="w-full max-w-xs text-center px-6 py-3 text-base font-bold text-slate-700 bg-slate-200 dark:bg-slate-600 dark:text-slate-200 rounded-lg shadow-sm hover:bg-slate-300 dark:hover:bg-slate-500 transition-all"
                                >
                                    لا أرغب في الحضور
                                </button>
                                <button
                                    onClick={() => onRegisterForEvent(event.id, currentUserAccount.id)}
                                    className="w-full max-w-xs text-center px-6 py-3 text-base font-bold text-white bg-teal-500 dark:bg-teal-600 rounded-lg shadow-md hover:bg-teal-600 dark:hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-all"
                                >
                                    تأكيد الحضور
                                </button>
                            </div>
                        )}
                    </footer>
                </div>
            );
        }

        const senderAccount = selectedItem.type === 'message' ? allAccounts.find(acc => acc.email === selectedItem.from) : null;
        const createdAt = (selectedItem.createdAt as any)?.toDate ? (selectedItem.createdAt as any).toDate() : new Date(selectedItem.createdAt);

        return (
            <div className="flex flex-col h-full">
                <header className="p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
                    <div className="flex justify-between items-center">
                        {/* Sender Info */}
                        <div className="flex items-center gap-3 min-w-0">
                            {selectedItem.type === 'message' && (
                                <Avatar account={senderAccount || { fullName: selectedItem.from }} size="w-11 h-11" />
                            )}
                            {selectedItem.type === 'alert' && (
                                <Avatar account={{fullName: "إدارة الاتحاد"}} size="w-11 h-11" />
                            )}
                            <div className="min-w-0">
                                {selectedItem.type === 'message' && (
                                    <>
                                        <p className="font-bold text-slate-800 dark:text-slate-200 truncate">{senderAccount?.fullName || selectedItem.from}</p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400 truncate">{`<${selectedItem.from}>`}</p>
                                    </>
                                )}
                                {selectedItem.type === 'alert' && (
                                    <>
                                        <p className="font-bold text-slate-800 dark:text-slate-200">تنبيه من إدارة الاتحاد</p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400">
                                            {createdAt.toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' })}
                                        </p>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-2 flex-shrink-0 ml-4">
                            {selectedItem.type === 'message' && (
                                <button
                                    onClick={() => openCompose(selectedItem.from)}
                                    className="flex items-center gap-2 text-sm bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 dark:hover:bg-slate-600 font-semibold px-3 py-1.5 rounded-lg transition-colors">
                                    <ArrowUturnLeftIcon className="w-4 h-4" />
                                    <span>رد</span>
                                </button>
                            )}
                            <button className="text-sm p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 dark:hover:bg-slate-600 font-semibold rounded-lg transition-colors"><TrashIcon className="w-5 h-5" /> </button>
                        </div>
                    </div>

                    {/* Subject line below */}
                    <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 mt-4">{selectedItem.subject}</h2>
                </header>
                <div className="p-6 text-slate-800 dark:text-slate-300 leading-relaxed whitespace-pre-wrap flex-1 overflow-y-auto">
                    {selectedItem.body}
                </div>
            </div>
        );
    };

  return (
    <>
        <div className="h-screen w-full flex flex-col text-slate-800 dark:text-slate-200">
            <header className="bg-white dark:bg-slate-800 text-slate-800 p-3 flex items-center justify-between shadow-md z-20 flex-shrink-0 border-b border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-4">
                    <BeShababhaLogo className="w-auto h-11" />
                    <span className="font-bold text-xl hidden sm:block dark:text-slate-100">بريد الاتحاد</span>
                </div>
                <div className="flex-1 max-w-2xl mx-4">
                    <div className="relative">
                        <MagnifyingGlassIcon className="w-5 h-5 text-slate-400 absolute top-1/2 right-3 -translate-y-1/2 pointer-events-none" />
                        <input type="search" placeholder="بحث في البريد..." className="w-full bg-slate-100 dark:bg-slate-700 placeholder-slate-400 dark:placeholder-slate-400 text-slate-800 dark:text-slate-100 rounded-full py-2.5 pl-4 pr-10 focus:outline-none focus:ring-2 focus:ring-amber-500 border border-transparent focus:border-amber-500 focus:bg-white dark:focus:bg-slate-600 transition-colors"/>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                     {currentUserAccount && <Avatar account={currentUserAccount} size="w-11 h-11" className="border-2 border-white shadow-sm" />}
                    <button onClick={onLogout} className="text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 p-2 rounded-full transition-colors" aria-label="تسجيل الخروج">
                        <LogoutIcon className="w-6 h-6" />
                    </button>
                </div>
            </header>

            <div className="flex flex-1 overflow-hidden">
                <aside className="w-64 bg-slate-50 dark:bg-slate-800/50 border-l border-slate-200 dark:border-slate-700 p-4 flex flex-col flex-shrink-0">
                    <div className="px-2 mb-6">
                        <button 
                            onClick={() => openCompose()}
                            className="w-full flex items-center justify-center gap-2 bg-amber-500 text-white font-bold py-3 px-4 rounded-xl hover:bg-amber-600 transition-colors duration-200 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
                        >
                            <PencilIcon className="w-5 h-5" />
                            <span>إنشاء رسالة</span>
                        </button>
                    </div>
                    <nav className="flex-1 space-y-2">
                        {sidebarItems.filter(item => item.visible).map(item => {
                            const count = item.id === 'inbox' ? unreadCount : item.id === 'alerts' ? alertsCount : undefined;
                            return (
                                <NavItem 
                                    key={item.id}
                                    icon={item.icon}
                                    label={item.label}
                                    viewName={item.id}
                                    count={count}
                                />
                            );
                        })}
                    </nav>
                    <div className="px-2 mt-4 border-t border-slate-200 dark:border-slate-700 pt-4">
                        <button 
                            onClick={() => setIsSettingsOpen(true)}
                            className="w-full flex items-center gap-3 text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 py-2.5 px-4 rounded-lg transition-colors"
                        >
                            <Cog6ToothIcon className="w-5 h-5"/>
                            <span>إعدادات الحساب</span>
                        </button>
                    </div>
                </aside>
                
                {view === 'participations' ? (
                     <main className="flex-grow bg-white dark:bg-slate-900 overflow-y-auto">
                        <ParticipationLogView account={currentUserAccount} onUpdateAccount={onUpdateAccount} />
                    </main>
                ) : (
                    <>
                        <section className="flex-1 w-full max-w-sm lg:max-w-md bg-white dark:bg-slate-800 border-l border-r border-slate-200 dark:border-slate-700 flex flex-col">
                            <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
                                <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
                                    {sidebarItems.find(i => i.id === view)?.label || 'البريد'}
                                </h1>
                            </div>
                            <div className="overflow-y-auto flex-1">
                                {renderMessageList()}
                            </div>
                        </section>
                        
                        <main className="flex-grow bg-white dark:bg-slate-800 overflow-y-auto hidden md:block">
                            {renderPreview()}
                        </main>
                    </>
                )}

            </div>
        </div>
        <ComposeModal 
            isOpen={isComposeOpen} 
            onClose={closeCompose}
            accounts={allAccounts}
            initialRecipient={initialRecipient}
            senderAccount={currentUserAccount}
            onSendMessage={onSendMessage}
        />
        <SettingsModal
            isOpen={isSettingsOpen}
            onClose={() => setIsSettingsOpen(false)}
            account={currentUserAccount}
            onUpdateAccount={onUpdateAccount}
            sidebarConfig={sidebarItems}
            onUpdateSidebarConfig={(newConfig) => {
                setSidebarItems(newConfig);
                localStorage.setItem('mailboxSidebarConfig', JSON.stringify(newConfig));
            }}
            theme={theme}
            onSetTheme={onSetTheme}
        />
    </>
  );
};

export default MailboxPage;
