import React, { useState } from 'react';
import CloseIcon from './icons/CloseIcon';
import MegaphoneIcon from './icons/MegaphoneIcon';

interface UrgentAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendAlert: (alert: { subject: string; body: string }) => void;
}

const UrgentAlertModal: React.FC<UrgentAlertModalProps> = ({ isOpen, onClose, onSendAlert }) => {
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    setError('');
    if (!subject || !body) {
      setError('الرجاء إدخال موضوع ونص التنبيه.');
      return;
    }
    onSendAlert({ subject, body });
    setSubject('');
    setBody('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all" onClick={(e) => e.stopPropagation()}>
        <header className="p-5 border-b border-slate-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-3">
              <MegaphoneIcon className="w-6 h-6 text-yellow-500" />
              إرسال تنبيه عاجل
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>
        <main className="p-6">
          <p className="text-slate-600 mb-6">
            سيتم إرسال هذا التنبيه إلى جميع أعضاء الاتحاد المسجلين وسيظهر في صندوق التنبيهات الخاص بهم.
          </p>
          <div className="space-y-4">
            <div>
              <label htmlFor="alert-subject" className="block text-sm font-medium text-slate-700 mb-1">الموضوع</label>
              <input type="text" id="alert-subject" value={subject} onChange={(e) => setSubject(e.target.value)} className="w-full px-4 py-2 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required />
            </div>
            <div>
              <label htmlFor="alert-body" className="block text-sm font-medium text-slate-700 mb-1">نص التنبيه</label>
              <textarea id="alert-body" value={body} onChange={(e) => setBody(e.target.value)} rows={6} className="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500" required></textarea>
            </div>
          </div>
          {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
        </main>
        <footer className="bg-slate-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200">
          <button onClick={onClose} className="bg-slate-200 text-slate-700 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 transition-colors">إلغاء</button>
          <button onClick={handleSubmit} className="bg-yellow-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-yellow-600 transition-colors shadow-sm hover:shadow-md">إرسال التنبيه</button>
        </footer>
      </div>
    </div>
  );
};

export default UrgentAlertModal;