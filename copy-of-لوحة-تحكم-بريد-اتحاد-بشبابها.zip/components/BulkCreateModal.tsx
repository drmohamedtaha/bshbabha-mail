import React, { useState } from 'react';
import type { EmailAccount } from '../types';
import CloseIcon from './icons/CloseIcon';
import UserGroupIcon from './icons/UserGroupIcon';

interface BulkCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBulkCreate: (accounts: EmailAccount[]) => void;
  domain: string;
}

const BulkCreateModal: React.FC<BulkCreateModalProps> = ({ isOpen, onClose, onBulkCreate, domain }) => {
  const [data, setData] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    setError('');
    const lines = data.split('\n').filter(line => line.trim() !== '');
    if (lines.length === 0) {
      setError('الرجاء إدخال بيانات الأعضاء.');
      return;
    }

    const newAccounts: EmailAccount[] = [];
    for (const line of lines) {
      const parts = line.split(',').map(p => p.trim());
      if (parts.length < 1 || !parts[0]) {
        setError(`خطأ في السطر: "${line}". يجب أن يحتوي كل سطر على الاسم الكامل على الأقل.`);
        return;
      }
      const fullName = parts[0];
      let username = parts[1] || fullName.toLowerCase().replace(/\s+/g, '.');
      username = username.toLowerCase().replace(/[^a-z0-9._-]/g, '');

      newAccounts.push({
        id: '', // Will be set by Firebase
        fullName,
        username,
        email: `${username}@${domain}`,
        password: Math.random().toString(36).slice(-10),
        createdAt: new Date().toISOString(),
        nationalId: '',
        dateOfBirth: '',
        governorate: '',
        unionPosition: 'عضو',
        mobileNumber: '',
        whatsappNumber: '',
        personalEmail: '',
        participations: [],
      });
    }

    onBulkCreate(newAccounts);
    setData('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-60 z-50 flex justify-center items-center p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl transform transition-all" onClick={(e) => e.stopPropagation()}>
        <header className="p-5 border-b border-slate-200">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-3">
              <UserGroupIcon className="w-6 h-6 text-amber-600" />
              إنشاء حسابات جماعية
            </h2>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
              <CloseIcon className="w-6 h-6" />
            </button>
          </div>
        </header>

        <main className="p-6">
          <div className="bg-yellow-50 text-yellow-800 p-3 rounded-lg border border-yellow-200 text-sm mb-4">
            <strong>ملاحظة هامة:</strong> هذه العملية ستضيف بيانات الأعضاء إلى قاعدة البيانات فقط. ستحتاج إلى إنشاء حسابات الدخول لهم يدويًا من خلال لوحة تحكم Firebase Authentication باستخدام البريد الإلكتروني وكلمة المرور التي تم إنشاؤها تلقائيًا.
          </div>
          <p className="text-slate-600 mb-4">
            أدخل بيانات الأعضاء في الحقل أدناه. كل سطر يمثل عضواً جديداً.
            <br />
            التنسيق: <code className="bg-slate-100 text-slate-800 text-sm px-1.5 py-0.5 rounded-md">الاسم الكامل,اسم المستخدم (اختياري)</code>.
          </p>

          <textarea
            value={data}
            onChange={(e) => setData(e.target.value)}
            rows={10}
            className="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono text-sm"
            placeholder="مثال:&#10;علي حسن,ali.hassan&#10;فاطمة الزهراء"
          ></textarea>
          
          {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
        </main>

        <footer className="bg-slate-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-slate-200">
          <button
            onClick={onClose}
            className="bg-slate-200 text-slate-700 font-semibold px-5 py-2.5 rounded-lg hover:bg-slate-300 transition-colors"
          >
            إلغاء
          </button>
          <button
            onClick={handleSubmit}
            className="bg-amber-500 text-white font-bold px-5 py-2.5 rounded-lg hover:bg-amber-600 transition-colors shadow-sm hover:shadow-md"
          >
            إضافة الحسابات
          </button>
        </footer>
      </div>
    </div>
  );
};

export default BulkCreateModal;
