import React from 'react';
import ShieldExclamationIcon from './icons/ShieldExclamationIcon';
import BeShababhaLogo from './icons/YouthUnionLogo';

const ConfigErrorPage: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 p-4">
      <div className="w-full max-w-lg p-8 text-center bg-white rounded-2xl shadow-2xl">
        <BeShababhaLogo className="w-auto h-24 mx-auto mb-6" />
        <ShieldExclamationIcon className="w-16 h-16 mx-auto text-red-400" />
        <h1 className="mt-6 text-2xl font-extrabold text-slate-900">
          خطأ في الإعدادات
        </h1>
        <p className="mt-4 text-slate-600 leading-relaxed">
          لم يتم العثور على متغيرات البيئة اللازمة لتشغيل التطبيق (مثل مفاتيح Firebase أو Gemini). هذا المفتاح ضروري لكي يعمل التطبيق بشكل صحيح.
        </p>
        <div className="mt-6 text-left bg-slate-50 p-4 rounded-lg border border-slate-200">
          <h2 className="font-bold text-slate-800">للمسؤول عن الموقع:</h2>
          <p className="mt-2 text-sm text-slate-600">
            الرجاء التأكد من إضافة جميع متغيرات البيئة المطلوبة (تبدأ بـ <code className="bg-slate-200 text-slate-800 text-xs px-1.5 py-1 rounded-md font-mono">VITE_</code>) وبقيمها الصحيحة في إعدادات النشر على منصة الاستضافة.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ConfigErrorPage;
