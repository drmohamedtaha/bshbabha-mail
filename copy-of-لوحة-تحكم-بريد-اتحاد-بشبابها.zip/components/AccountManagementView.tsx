import React, { useState } from 'react';
import type { EmailAccount } from '../types';
import TrashIcon from './icons/TrashIcon';
import PencilIcon from './icons/PencilIcon';
import EditAccountModal from './EditAccountModal';
import PaperAirplaneIcon from './icons/PaperAirplaneIcon';
import Avatar from './Avatar';
import UserGroupIcon from './icons/UserGroupIcon';

interface AccountManagementViewProps {
  accounts: EmailAccount[];
  onUpdateAccount: (account: EmailAccount) => void;
  onDeleteAccount: (id: string) => void;
  onComposeMessage: (recipient?: string) => void;
}

const AccountManagementView: React.FC<AccountManagementViewProps> = ({ accounts, onUpdateAccount, onDeleteAccount, onComposeMessage }) => {
  const [editingAccount, setEditingAccount] = useState<EmailAccount | null>(null);

  const handleDelete = (id: string, fullName: string) => {
    if (window.confirm(`هل أنت متأكد من حذف حساب ${fullName}؟ هذا الإجراء سيحذف بياناته من قاعدة البيانات.`)) {
      onDeleteAccount(id);
    }
  };

  const handleCloseModal = () => {
    setEditingAccount(null);
  };

  const getFormattedDate = (createdAt: any) => {
    if (!createdAt) return 'N/A';
    if (typeof createdAt === 'string') return new Date(createdAt).toLocaleDateString('ar-EG');
    if (createdAt.toDate) return createdAt.toDate().toLocaleDateString('ar-EG');
    return 'Invalid Date';
  }

  return (
    <>
      <div>
        {accounts.length === 0 ? (
          <div className="text-center py-20 px-6 bg-white rounded-2xl shadow-xl">
            <UserGroupIcon className="w-16 h-16 mx-auto text-slate-300" />
            <h3 className="text-xl font-semibold text-slate-700 mt-4">لا توجد حسابات لعرضها</h3>
            <p className="text-slate-500 mt-2">يمكنك إنشاء حسابات جديدة من تبويب "إنشاء حساب فردي" أو "إنشاء جماعي".</p>
          </div>
        ) : (
          <div className="bg-white shadow-xl rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th scope="col" className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">الاسم الكامل</th>
                    <th scope="col" className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">البريد الإلكتروني / الصفة</th>
                    <th scope="col" className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">تاريخ الإنشاء</th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">الإجراءات</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {accounts.map((account) => (
                    <tr key={account.id} className="hover:bg-slate-50 transition-colors duration-200">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center gap-4">
                            <Avatar account={account} size="w-11 h-11" />
                            <div className="text-sm font-semibold text-slate-900">{account.fullName}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                        <div>{account.email}</div>
                        <div className="text-xs text-slate-400">{account.unionPosition}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{getFormattedDate(account.createdAt)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onComposeMessage(account.email)}
                            className="text-slate-500 hover:text-green-600 transition-colors p-2 rounded-full hover:bg-green-50"
                            aria-label={`إرسال رسالة إلى ${account.fullName}`}
                          >
                            <PaperAirplaneIcon className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => setEditingAccount(account)}
                            className="text-slate-500 hover:text-amber-600 transition-colors p-2 rounded-full hover:bg-amber-50"
                            aria-label={`تعديل حساب ${account.fullName}`}
                          >
                            <PencilIcon className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => handleDelete(account.id, account.fullName)}
                            className="text-slate-500 hover:text-red-600 transition-colors p-2 rounded-full hover:bg-red-50"
                            aria-label={`حذف حساب ${account.fullName}`}
                          >
                            <TrashIcon className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {editingAccount && (
        <EditAccountModal
          isOpen={!!editingAccount}
          onClose={handleCloseModal}
          account={editingAccount}
          onUpdateAccount={onUpdateAccount}
          domain={editingAccount.email.split('@')[1]}
        />
      )}
    </>
  );
};

export default AccountManagementView;
