import React, { useState, useEffect } from 'react';
import BeShababhaLogo from './icons/YouthUnionLogo.tsx';
import ForgotPasswordModal from './ForgotPasswordModal';

interface LoginPageProps {
  loginMessage: string | null;
  onNavigateToRegister: () => void;
  onNavigateToAdminLogin: () => void;
  onLogin: (email: string, password: string) => Promise<void>;
  onPasswordReset: (personalEmail: string) => Promise<void>;
}

const LoginPage: React.FC<LoginPageProps> = ({ loginMessage, onNavigateToRegister, onNavigateToAdminLogin, onLogin, onPasswordReset }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);

  useEffect(() => {
    const rememberedUser = localStorage.getItem('rememberedUser');
    if (rememberedUser) {
      setUsername(rememberedUser);
      setRememberMe(true);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!username || !password) {
      setError('الرجاء إدخال اسم المستخدم وكلمة المرور.');
      setIsLoading(false);
      return;
    }

    try {
      const email = `${username.toLowerCase()}@youthunion.org`;
      await onLogin(email, password);
      if (rememberMe) {
        localStorage.setItem('rememberedUser', username);
      } else {
        localStorage.removeItem('rememberedUser');
      }
    } catch (err: any) {
        if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found') {
             setError('اسم المستخدم أو كلمة المرور غير صحيحة.');
        } else {
             setError('حدث خطأ أثناء تسجيل الدخول. الرجاء المحاولة مرة أخرى.');
        }
        console.error(err);
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <>
      <div className="flex items-center justify-center min-h-screen bg-slate-100 p-4">
        <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-2xl">
          <div className="text-center">
              <BeShababhaLogo className="w-auto h-28 mx-auto" />
            <h2 className="mt-6 text-3xl font-extrabold text-slate-900">
              تسجيل الدخول
            </h2>
             <p className="mt-2 text-sm text-slate-500">
              مرحباً بك في منصة بريد اتحاد بشبابها.
            </p>
          </div>
          
          {loginMessage && (
            <div className="text-sm text-center text-green-800 bg-green-100 p-3 rounded-lg border border-green-200">
              {loginMessage}
            </div>
          )}

          <form className="mt-8 space-y-6" onSubmit={handleLogin}>
            <div className="space-y-4">
              <div>
                <label htmlFor="username" className="sr-only">اسم المستخدم</label>
                 <div className="flex items-center bg-slate-50 border border-slate-300 rounded-lg shadow-sm focus-within:ring-2 focus-within:ring-amber-500 overflow-hidden transition">
                    <input
                      id="username"
                      name="username"
                      type="text"
                      autoComplete="username"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="flex-grow w-full px-4 py-3 border-0 focus:outline-none focus:ring-0 bg-transparent text-left placeholder-slate-400"
                      placeholder="اسم المستخدم"
                    />
                    <span className="px-4 bg-slate-200 text-slate-500 self-stretch flex items-center border-r border-slate-300 font-mono text-sm">@youthunion.org</span>
                </div>
              </div>
              <div>
                <label htmlFor="password" aria-label="كلمة المرور" className="sr-only">كلمة المرور</label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-lg shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
                  placeholder="كلمة المرور"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-amber-600 border-slate-300 rounded focus:ring-amber-500"
                />
                <label htmlFor="remember-me" className="block mr-2 text-sm text-slate-800">
                  تذكرني
                </label>
              </div>
              <div className="text-sm">
                <button
                  type="button"
                  onClick={() => setIsForgotPasswordOpen(true)}
                  className="font-semibold text-amber-600 hover:text-amber-700"
                >
                  نسيت كلمة السر؟
                </button>
              </div>
            </div>

            {error && <p className="text-sm text-center text-red-700 bg-red-100 p-3 rounded-lg border border-red-200">{error}</p>}

            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center px-4 py-3 text-base font-bold text-white bg-amber-500 border border-transparent rounded-lg shadow-md hover:bg-amber-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transform hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? ( <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> ) : 'تسجيل الدخول'}
              </button>
            </div>
          </form>
          <div className="text-sm text-center text-slate-500 pt-6 mt-6 border-t border-slate-200 space-y-4">
              <p>
                  ليس لديك حساب؟{' '}
                  <button
                      onClick={onNavigateToRegister}
                      className="font-semibold text-amber-600 hover:text-amber-700 underline"
                  >
                      إنشاء حساب جديد
                  </button>
              </p>
               <p>
                  أو{' '}
                  <button
                      onClick={onNavigateToAdminLogin}
                      className="font-semibold text-slate-700 hover:text-slate-900 underline"
                  >
                      الدخول كمسؤول
                  </button>
                  {' '}لإدارة الحسابات.
              </p>
          </div>
        </div>
      </div>
      <ForgotPasswordModal 
        isOpen={isForgotPasswordOpen}
        onClose={() => setIsForgotPasswordOpen(false)}
        onPasswordReset={onPasswordReset}
      />
    </>
  );
};

export default LoginPage;
