
import React from 'react';
import PlusIcon from './icons/PlusIcon';
import UserGroupIcon from './icons/UserGroupIcon';

interface HeaderProps {
  onBulkCreateClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onBulkCreateClick }) => {
  return (
    <header className="bg-white shadow-md p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold text-gray-800">لوحة تحكم بريد اتحاد بشبابها</h1>
      <div className="flex items-center gap-4">
        <button 
          onClick={onBulkCreateClick}
          className="flex items-center gap-2 bg-indigo-100 text-indigo-600 hover:bg-indigo-200 font-semibold px-4 py-2 rounded-lg transition-colors duration-200">
          <UserGroupIcon className="w-5 h-5" />
          <span>إنشاء جماعي</span>
        </button>
      </div>
    </header>
  );
};

export default Header;